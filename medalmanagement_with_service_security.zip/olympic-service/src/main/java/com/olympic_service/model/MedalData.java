package com.olympic_service.model;

public class MedalData {
    private String id;
   // private String Country;
    private String NOC;
    private int Gold;
    private int Silver;
    private int Bronze;
    private int Total;
   /* private int medalRank;*/


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

   /* public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }*/

    public String getNOC() {
        return NOC;
    }

    public void setNOC(String NOC) {
        this.NOC = NOC;
    }

    public int getGold() {
        return Gold;
    }

    public void setGold(int gold) {
        Gold = gold;
    }

    public int getSilver() {
        return Silver;
    }

    public void setSilver(int silver) {
        Silver = silver;
    }

    public int getBronze() {
        return Bronze;
    }

    public void setBronze(int bronze) {
        Bronze = bronze;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }

    /*public int getMedalRank() {
        return medalRank;
    }

    public void setMedalRank(int medalRank) {
        this.medalRank = medalRank;
    }*/

    @Override
    public String toString() {
        return "MedalData{" +
                "id='" + id + '\'' +
                ", NOC='" + NOC + '\'' +
                ", Gold=" + Gold +
                ", Silver=" + Silver +
                ", Bronze=" + Bronze +
                ", Total=" + Total +
                /*",medalRank" + medalRank +*/
                '}';
    }
}
