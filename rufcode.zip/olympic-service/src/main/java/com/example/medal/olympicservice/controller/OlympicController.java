package com.example.medal.olympicservice.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
@RestController public class OlympicController {
    @Autowired private RestTemplate rest; @Autowired private KafkaTemplate<String, String> kafka;
    @GetMapping("/olympics/fetch") public Object fetchAndPublish(){
        String url = "http://localhost:3232/olympicapi/olympics";
        Object data = rest.getForObject(url, Object.class);
        try { kafka.send("olympic-topic", data.toString()); } catch(Exception e){ e.printStackTrace(); }
        return data;
    }
}