package com.example.medal.olympic.controller;

import jakarta.annotation.PostConstruct;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/olympic")
public class OlympicController {

    private final RestTemplate rt = new RestTemplate();

    // Example: import from a local olympic api and post to analysis service
    @GetMapping("/import")
    public ResponseEntity<?> importFromApi(@RequestParam(defaultValue = "http://localhost:3232/olympicapi/olympics") String sourceUrl,
                                           @RequestHeader(value = "Authorization", required = false) String auth) {
        ResponseEntity<List> resp = rt.getForEntity(sourceUrl, List.class);
        if (!resp.getStatusCode().is2xxSuccessful()) {
            return ResponseEntity.status(502).body("upstream error");
        }
        List countries = resp.getBody();
        // forward each to analysis service
        String analysisUrl = System.getenv().getOrDefault("ANALYSIS_URL", "http://localhost:9200/analysis/country");
        String token = null;
        if (auth != null && auth.startsWith("Bearer ")) token = auth.substring(7);
        for (Object o : countries) {
            try {
                Map m = (Map) o;
                Map payload = Map.of(
                    "noc", m.getOrDefault("noc", m.get("country")),
                    "gold", m.getOrDefault("gold", 0),
                    "silver", m.getOrDefault("silver", 0),
                    "bronze", m.getOrDefault("bronze", 0)
                );
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                if (token != null) headers.set("Authorization", "Bearer " + token);
                HttpEntity<Map> request = new HttpEntity<>(payload, headers);
                rt.exchange(analysisUrl, HttpMethod.POST, request, String.class);
            } catch (Exception ex) {
                // ignore per-item errors for resilience in this simple demo
            }
        }
        return ResponseEntity.ok(Map.of("imported", countries.size()));
    }
}
