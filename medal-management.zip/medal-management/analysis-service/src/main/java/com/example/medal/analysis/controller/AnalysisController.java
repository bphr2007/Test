package com.example.medal.analysis.controller;

import com.example.medal.analysis.model.CountryMedal;
import com.example.medal.analysis.repo.CountryMedalRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/analysis")
public class AnalysisController {

    private final CountryMedalRepository repo;

    public AnalysisController(CountryMedalRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/country")
    public ResponseEntity<?> upsert(@RequestBody CountryMedal cm) {
        Optional<CountryMedal> existing = repo.findByNoc(cm.getNoc());
        if (existing.isPresent()) {
            CountryMedal e = existing.get();
            e.setGold(cm.getGold());
            e.setSilver(cm.getSilver());
            e.setBronze(cm.getBronze());
            repo.save(e);
            return ResponseEntity.ok(e);
        } else {
            var saved = repo.save(cm);
            return ResponseEntity.ok(saved);
        }
    }

    @GetMapping("/country/{noc}")
    public ResponseEntity<?> get(@PathVariable String noc) {
        return repo.findByNoc(noc).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/rankings")
    public ResponseEntity<?> rankings(@RequestParam(defaultValue = "total") String by) {
        List<CountryMedal> all = repo.findAll();
        if ("gold".equalsIgnoreCase(by)) {
            all.sort(Comparator.comparingInt(CountryMedal::getGold).reversed());
        } else if ("silver".equalsIgnoreCase(by)) {
            all.sort(Comparator.comparingInt(CountryMedal::getSilver).reversed());
        } else {
            all.sort(Comparator.comparingInt(CountryMedal::getTotal).reversed());
        }
        return ResponseEntity.ok(all);
    }
}
