package com.authentication_service.dto;

public class UserDTO {
    private Long userid;
    private String username;
    private String password;
    private String phone;
    private String country;
    private Integer age;

    public UserDTO(Long userid, String username, String password, String phone, String country, Integer age) {
        this.userid = userid;
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.country = country;
        this.age = age;

    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
