Medal Management - Multi-module project (no discovery, no gateway)
Modules:
- shared
- auth-service
- user-profile-service
- analysis-service
- olympic-service

Prereqs:
- Java 17, Maven
- MySQL running on localhost with a root user (or update application.yml files).
- Create databases:
  CREATE DATABASE medal_userdb;
  CREATE DATABASE medal_analysisdb;

Build:
  mvn -T 1C clean install

Run (in separate terminals):
  cd user-profile-service
  mvn spring-boot:run

  cd ../analysis-service
  mvn spring-boot:run

  cd ../auth-service
  mvn spring-boot:run

  cd ../olympic-service
  mvn spring-boot:run

Typical flow:
- POST /profile/register  (http://localhost:9100/profile/register) to register user
- POST /auth/login (http://localhost:9000/auth/login) to get token
- Use token to call analysis endpoints (http://localhost:9200/analysis/...)

Notes:
- Shared JwtUtil uses an in-code secret for demo only. Replace with env secret in production.
- Each service validates JWT independently.
