package com.stackroute.bookmark.controller;

import com.stackroute.bookmark.dto.BookmarkGrievanceDTO;
import com.stackroute.bookmark.model.BookmarkGrievance;
import com.stackroute.bookmark.service.BookmarkGrievanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.Inet4Address;
import java.util.List;

@RestController
@RequestMapping("bookmark")
public class BookmarkController {

    @Autowired
    BookmarkGrievanceService bookmarkService;

    @PostMapping("/add")
    public ResponseEntity<String> saveBookmarkGrievance(@RequestBody BookmarkGrievanceDTO bookmarkDTO){
        BookmarkGrievance grievance = bookmarkService.add(bookmarkDTO);
        return ResponseEntity.ok("Saved Successfully");

    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookmarkGrievance>> retrieveBookmarksByUserId(@PathVariable("userId") Integer userId){
       List<BookmarkGrievance> bookmarksList = bookmarkService.retrieveBookmarksByUserId(userId);
       return ResponseEntity.ok(bookmarksList);
    }

    @DeleteMapping("/{complaintId}")
    public ResponseEntity<Void> deleteGrievanceByComplaintId(@PathVariable("complaintId") String complaintId){
          bookmarkService.deleteGrievanceByComplaintId(complaintId);
          return ResponseEntity.noContent().build();
    }
}
