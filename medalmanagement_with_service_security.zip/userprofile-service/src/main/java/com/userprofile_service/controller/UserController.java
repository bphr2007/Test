package com.userprofile_service.controller;


import com.userprofile_service.model.User;
import com.userprofile_service.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")

public class UserController {
    @Autowired
    private  UserService userService;

    @GetMapping("/viewUsers")
    public ResponseEntity<?> getView(){
        List<User> users=   userService.getAllUsers();

        return new ResponseEntity<List>(users, HttpStatus.OK);
    }
    /*@PostMapping("/validate")
    public ResponseEntity<UserDTO> validate(@RequestBody AuthRequest request) {

        return ResponseEntity.ok(userService.validateUser(request));
    }*/



    @PostMapping("/addUser")
    public ResponseEntity<User> create(@RequestBody User user) {

        return ResponseEntity.ok(userService.create(user));
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> update(@PathVariable Long id, @RequestBody User user) {
        return ResponseEntity.ok(userService.update(id, user));
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> get(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
