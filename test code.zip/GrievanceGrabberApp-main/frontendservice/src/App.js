import logo from './logo.svg';
import './App.css';
import UserRegistration from './Components/UserRegistration/UserRegistration';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './Components/Header/Header';
import Login from './Components/Login/Login';
import Grievance from './Components/Grievance/Grievance';
import Bookmark from './Components/Bookmark/Bookmark';
import UpdateUserProfile from './Components/UpdateUserProfile/UpdateUserProfile';
import Logout from './Components/Logout/Logout';
import ProtectRoute from './Components/ProtectRoute/ProtectRoute';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/grievance" element={<ProtectRoute><Grievance /></ProtectRoute>} />
          <Route path="/bookmark" element={<ProtectRoute><Bookmark /></ProtectRoute>} />
          <Route path="/register" element={<UserRegistration />} />
          <Route path="/login" element={<Login />} />
          <Route path="/updateUserProfile" element={<ProtectRoute><UpdateUserProfile /></ProtectRoute>} />
          <Route path="/logout" element={<Logout />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
