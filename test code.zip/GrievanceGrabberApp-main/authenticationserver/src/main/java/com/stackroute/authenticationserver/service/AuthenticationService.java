package com.stackroute.authenticationserver.service;
import java.util.Optional;

import com.google.gson.Gson;
import com.stackroute.authenticationserver.model.User;
import com.stackroute.authenticationserver.model.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.stackroute.authenticationserver.repo.UserRepo;
 

@Service
public class AuthenticationService {

	@Autowired
	UserRepo userRepo;

	@Autowired
	Gson gson;


	@KafkaListener(topics = "registerusertopic", groupId = "userAuthGroupId1")
	public void registerUser(String userData)
	{
        UserDto userDto = gson.fromJson(userData, UserDto.class);
		userRepo.save(new User(userDto.email(), userDto.password()));
	}
	
	public Optional<User> validateUser(UserDto user)
	{
		return userRepo.findByUseremailAndPassword(user.email(), user.password());

	}
	
}
