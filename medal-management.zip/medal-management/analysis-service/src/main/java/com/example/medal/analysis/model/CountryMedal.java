package com.example.medal.analysis.model;

import jakarta.persistence.*;

@Entity
@Table(name = "country_medal")
public class CountryMedal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String noc;
    private int gold;
    private int silver;
    private int bronze;

    public CountryMedal() {}
    public CountryMedal(String noc, int gold, int silver, int bronze) {
        this.noc = noc; this.gold = gold; this.silver = silver; this.bronze = bronze;
    }
    public Long getId() { return id; }
    public String getNoc() { return noc; }
    public void setNoc(String noc) { this.noc = noc; }
    public int getGold() { return gold; }
    public void setGold(int gold) { this.gold = gold; }
    public int getSilver() { return silver; }
    public void setSilver(int silver) { this.silver = silver; }
    public int getBronze() { return bronze; }
    public void setBronze(int bronze) { this.bronze = bronze; }
    public int getTotal() { return gold + silver + bronze; }
}
