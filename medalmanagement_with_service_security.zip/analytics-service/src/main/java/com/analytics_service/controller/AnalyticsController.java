package com.analytics_service.controller;

import com.analytics_service.model.MedalDataSummary;
import com.analytics_service.service.AnalyticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("analytics")
public class AnalyticsController {

    @Autowired
    AnalyticsService analyticsService;


    @GetMapping("/getMedalData")
    public ResponseEntity<List<MedalDataSummary>> getMedalData() {
        return ResponseEntity.ok(analyticsService.getAll());
    }
    @GetMapping("/getRankings")
    public ResponseEntity<List<MedalDataSummary>> getRankings() {
        return ResponseEntity.ok(analyticsService.getRankings());
    }

    @PutMapping("/{id}")
    public ResponseEntity<MedalDataSummary> update(@PathVariable String id, @RequestBody MedalDataSummary data) {
        return ResponseEntity.ok(analyticsService.update(id, data));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        analyticsService.delete(id);
        return ResponseEntity.noContent().build();
    }

    /*@GetMapping("/rankings/{type}")
    public ResponseEntity<List<MedalDataSummary>> filterByType(@PathVariable String type) {
        return ResponseEntity.ok(analyticsService.filterByMedalType(type));
    }
*/
    @GetMapping("/country/{NOC}")
    public ResponseEntity<MedalDataSummary> filterByCountry(@PathVariable String NOC) {
        return ResponseEntity.ok(analyticsService.filterByCountry(NOC));
    }
}
