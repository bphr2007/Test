package com.stackroute.bookmark.repository;

import com.stackroute.bookmark.model.BookmarkGrievance;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

@DataJpaTest
public class BookmarkGrievanceRepositoryTests {
    @Autowired
    BookmarkGrievanceRepository bookmarkRepo;

    BookmarkGrievance bookmarkGrievance;

    @BeforeEach
    public void setUp(){
        bookmarkGrievance = new BookmarkGrievance();
        bookmarkGrievance.setCompany("Kotak");
        bookmarkGrievance.setProduct("CreditCard");
        bookmarkGrievance.setIssue("Card Expired");
        bookmarkGrievance.setCompanyResponse("New Card Replaced");
        bookmarkGrievance.setComplaintId("1");
        bookmarkGrievance.setTimely("yes");
        bookmarkGrievance.setUserId(1);
    }

    @Test
    @DisplayName("Junit Test case for save BookmarkGrievance")
    public void givenBookmarkGrievance_whenSave_thenReturnBookmarkGrievance(){
        //given - precondition or setup

        //when - action or the behaviour that we are going to test
        BookmarkGrievance savedBookmark= bookmarkRepo.save(bookmarkGrievance);

        //then - verify output
        Assertions.assertNotNull(savedBookmark);
        Assertions.assertNotNull(savedBookmark.getId());
    }

    @Test
    @DisplayName("Junit Test case for Get By UserId")
    public void givenBookmarkGrievanceList_whenFindByUserId_thenReturnBookmarkList(){
        //given - precondition or setup
        BookmarkGrievance bookmarkGrievance2 = new BookmarkGrievance();
        bookmarkGrievance2.setCompany("HDFC");
        bookmarkGrievance2.setProduct("CreditCard");
        bookmarkGrievance2.setIssue("Card Expired");
        bookmarkGrievance2.setCompanyResponse("New Card Replaced");
        bookmarkGrievance2.setComplaintId("1");
        bookmarkGrievance2.setTimely("yes");
        bookmarkGrievance2.setUserId(1);
        bookmarkRepo.save(bookmarkGrievance);
        bookmarkRepo.save(bookmarkGrievance2);

        //when - action or behaviour to test
        List<BookmarkGrievance> bookmarkList = bookmarkRepo.findByUserId(1);

        //then -  verify output
        Assertions.assertNotNull(bookmarkList);
        Assertions.assertEquals(2, bookmarkList.size());
    }

    @Test
    public void givenBookmarkGrievance_whenDelete_thenRemoveBookmarkGrievance(){
        //given - precondition or setup
        bookmarkRepo.save(bookmarkGrievance);

        //when - action or behaviour to test
        bookmarkRepo.deleteById(bookmarkGrievance.getId());
        Optional<BookmarkGrievance> bookmarkOptional=bookmarkRepo.findById(bookmarkGrievance.getId());

        //then - verify output
        Assertions.assertTrue(bookmarkOptional.isEmpty());
    }

    @Test
    public void givenBookmarkGrievance_whenExists_thenReturnExistence(){
        //given - precondition or setup
        bookmarkRepo.save(bookmarkGrievance);

        //when - action or behaviour to test
        Boolean isAvaiable = bookmarkRepo.existsByComplaintId(bookmarkGrievance.getComplaintId());

        //then - verify output
        Assertions.assertTrue(isAvaiable);
    }

}
