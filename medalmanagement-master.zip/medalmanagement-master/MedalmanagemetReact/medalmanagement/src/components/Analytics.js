import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './Analytic.css';

function Analytics() {
  const { countryCode } = useParams(); // Get the country code from the URL
  const [analyticsData, setAnalyticsData] = useState(null);

  useEffect(() => {
    const fetchAnalyticsData = async () => {
      const token = localStorage.getItem('token'); // Get the token from localStorage (or sessionStorage)

      if (!token) {
        console.log('No token found, redirecting to login');
        // Redirect the user to the login page or handle accordingly
        // For example:
        // history.push('/login'); // If using react-router
        return;
      }

      try {
        const res = await fetch(`http://localhost:8085/analytics/country/${countryCode}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`, // Send token in the Authorization header
            'Content-Type': 'application/json', // Adjust if your API expects a specific content type
          },
        });
        console.log(res);
        const data = await res.json();

        if (res.ok) {
          setAnalyticsData(data);
        } else {
          console.log('Failed to fetch analytics data');
          // Handle token expiry or error response, e.g., logout the user
        }
      } catch (error) {
        console.error('Error fetching analytics data:', error);
      }
    };

    if (countryCode) {
      fetchAnalyticsData();
    }
  }, [countryCode]);

  const handleUpdate = () => {
    console.log('Update clicked');
    // Your update logic here
  };

  const handleDelete = () => {
    console.log('Delete clicked');
    // Your delete logic here
  };

  return (
    <div>
      <h2>Analytics for {countryCode}</h2>
      {analyticsData ? (
        <div>
          <table border="1" cellPadding="10">
            <thead>
              <tr>
                <th>Gold</th>
                <th>Silver</th>
                <th>Bronze</th>
                <th>Total Medals</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{analyticsData.gold}</td>
                <td>{analyticsData.silver}</td>
                <td>{analyticsData.bronze}</td>
                <td>{analyticsData.total}</td>
                <td>
                  <button onClick={handleUpdate}>Update</button>
                  <button onClick={handleDelete}>Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      ) : (
        <p>Loading analytics data...</p>
      )}
    </div>
  );
}

export default Analytics;
