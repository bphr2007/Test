package com.analytics_service.kafka;

import com.analytics_service.model.MedalDataSummary;
import com.analytics_service.repository.AnalyticsRepository;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import com.google.gson.reflect.TypeToken;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.lang.reflect.Type;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OlympicConsumer {
    @Autowired
    Gson gson;

    @Autowired
    private  AnalyticsRepository repository;
   /* @KafkaListener(topics = "MedalSummary-topic", groupId = "group1")
    public void consume(String message) {

        // 1. Deserialize Kafka message
        Type listType = new TypeToken<List<MedalDataSummary>>() {}.getType();
        List<MedalDataSummary> incomingData = gson.fromJson(message, listType);

        if (incomingData == null || incomingData.isEmpty()) {
            System.out.println("No data received from Kafka.");
            return;
        }

        // 2. Fetch existing data from DB
        List<MedalDataSummary> existingData = repository.findAll();

        // 3. Update existing records or add new ones
        for (MedalDataSummary newData : incomingData) {
            existingData.stream()
                    .filter(existing -> existing.getId().equals(newData.getId()))
                    .findFirst()
                    .ifPresentOrElse(existing -> {
                        // Update medals if ID exists

                    }, () -> {
                        // Add new record if ID not present
                        existingData.add(newData);
                    });
        }

        // 4. Sort data by total -> gold -> silver -> bronze to calculate ranks
        existingData.sort((o1, o2) -> {
            int totalCompare = Integer.compare(o2.getTotal(), o1.getTotal());
            if (totalCompare != 0) return totalCompare;

            int goldCompare = Integer.compare(o2.getGold(), o1.getGold());
            if (goldCompare != 0) return goldCompare;

            int silverCompare = Integer.compare(o2.getSilver(), o1.getSilver());
            if (silverCompare != 0) return silverCompare;

            return Integer.compare(o2.getBronze(), o1.getBronze());
        });

        // 5. Assign ranks
        int rank = 1;
        for (MedalDataSummary data : existingData) {
            data.setMedalRank(rank++);
        }

        // 6. Save updated records back to DB
        repository.saveAll(existingData);
        System.out.println("Database updated. Total records: " + existingData.size());
    }*/



        //@KafkaListener(topics = "medal-topic", groupId = "group1")
   @KafkaListener(topics = "MedalSummary-topic", groupId = "group1")
    public void consume(String message ) {

            Type listType = new TypeToken<List<MedalDataSummary>>() {
            }.getType();
            List<MedalDataSummary> medalDataList = gson.fromJson(message, listType);

            List<MedalDataSummary> newRecords = medalDataList.stream()
                    .filter(medal -> medal.getId() != null && !repository.existsById(medal.getId()))
                    .collect(Collectors.toList());

        System.out.println("Received data from kafka: " + newRecords);
            if (!newRecords.isEmpty()) {
                repository.saveAll(newRecords);
                System.out.println("Inserted new records: " + newRecords.size());
            } else {
                System.out.println("Data Already present ");
            }


        }

}
