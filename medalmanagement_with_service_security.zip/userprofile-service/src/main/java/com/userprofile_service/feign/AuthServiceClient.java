package com.userprofile_service.feign;

import com.userprofile_service.dto.AuthRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "authentication-service", url = "http://localhost:8081")
public interface AuthServiceClient {

    @PostMapping("/auth/create")
    void createAuthUser(@RequestBody AuthRequest request);
}
