package com.example.medal.olympicservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class OlympicServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(OlympicServiceApplication.class, args);
    }
}

@RestController
class OlympicServiceApplicationHealth {
    @GetMapping("/health")
    public String health() {
        return "olympic-service OK";
    }
}
