package com.example.medal.auth;

import com.example.medal.shared.dto.LoginRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class AuthControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void testLoginInvalidUser() {
        LoginRequest req = new LoginRequest("noone", "bad");
        ResponseEntity<Map> resp = restTemplate.postForEntity("/auth/login", req, Map.class);
        assertEquals(500, resp.getStatusCode().value(), "Expected 500 because user-profile not reachable in test without mock");
    }
}
