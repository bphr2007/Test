package com.olympic_service.kafka;

import com.olympic_service.model.MedalData;
import com.olympic_service.model.MedalSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class OlympicProducer {
    @Autowired
    private  KafkaTemplate<String, List<MedalSummary>> kafkaTemplate;

  /*  private  KafkaTemplate<String, MedalSummary> kafkaTemplate =new KafkaTemplate<>();

    @Autowired
    public OlympicProducer(KafkaTemplate<String, MedalSummary> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }*/

  //  public void sendToKafka(MedalData data) {
        public void sendListToKafka(List<MedalData> dataList) {
            List<MedalSummary> summaries = dataList.stream()
                    .map(data -> {
                        MedalSummary medalSummary = new MedalSummary();
                        medalSummary.setId(data.getId());
                        medalSummary.setGold(data.getGold());
                        medalSummary.setSilver(data.getSilver());
                        medalSummary.setBronze(data.getBronze());
                        medalSummary.setNoc(data.getNOC());
                        return medalSummary;
                    })
                    .toList();
        kafkaTemplate.send("MedalSummary-topic",  summaries);
    }


}
