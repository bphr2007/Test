package com.stackroute.bookmark.service;

import com.stackroute.bookmark.dto.BookmarkGrievanceDTO;
import com.stackroute.bookmark.exception.ResourceNotFoundException;
import com.stackroute.bookmark.model.BookmarkGrievance;
import com.stackroute.bookmark.repository.BookmarkGrievanceRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.print.Book;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class BookmarkGrievanceServiceTests {

    @Mock
    BookmarkGrievanceRepository bookmarkRepo;

    @InjectMocks
    BookmarkGrievanceServiceImpl bookmarkService;

    BookmarkGrievance bookmarkGrievance;

    BookmarkGrievanceDTO grievanceDTO;

    @BeforeEach
    public void setUp(){
        //DTO
        grievanceDTO = new BookmarkGrievanceDTO(1, "1", "Kotak", "CreditCard",
                "Card Expired", "New Card Replaced", "yes",1);

        //Model
        bookmarkGrievance = new BookmarkGrievance();
        bookmarkGrievance.setId(1);
        bookmarkGrievance.setCompany(grievanceDTO.company());
        bookmarkGrievance.setProduct(grievanceDTO.product());
        bookmarkGrievance.setIssue(grievanceDTO.issue());
        bookmarkGrievance.setCompanyResponse(grievanceDTO.companyResponse());
        bookmarkGrievance.setComplaintId(grievanceDTO.complaintId());
        bookmarkGrievance.setTimely(grievanceDTO.timely());
        bookmarkGrievance.setUserId(grievanceDTO.userId());
    }

    @Test
    @DisplayName("Junit Test case for save Employee")
    public  void givenBookmarkGrievanceObj_whenSaveObj_thenReturnBookmarkGrievanceObj(){
        //Given - precondition or setup
        BDDMockito.given(bookmarkRepo.existsByComplaintId(bookmarkGrievance.getComplaintId())).willReturn(Boolean.FALSE);
        BDDMockito.given(bookmarkRepo.save(BDDMockito.any(BookmarkGrievance.class))).willReturn(bookmarkGrievance);

        //when - action or behaviour to be tested
        BookmarkGrievance savedBookmark = bookmarkService.add(grievanceDTO);

        //then - verify output
        Assertions.assertThat(savedBookmark).isNotNull();
    }

    @Test
    @DisplayName("Junit Test case for save Employee method throws Exception")
    public  void givenExistingComplaintId_whenSaveObj_thenThrowException(){
        //Given - precondition or setup
        BDDMockito.given(bookmarkRepo.existsByComplaintId(bookmarkGrievance.getComplaintId())).willReturn(Boolean.TRUE);

        //when - action or behaviour to be tested
        org.junit.jupiter.api.Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            bookmarkService.add(grievanceDTO);
        });

        //then - verify output
        BDDMockito.verify(bookmarkRepo, Mockito.never()).save(Mockito.any(BookmarkGrievance.class));
    }

    @Test
    @DisplayName("Junit test for Retrieve BookmarkGrievance by UserId")
    public void givenBookmarkGrievanceList_whenRetrieveBookmarksByUserId_thenReturnBookmarkGrievanceList(){
        //given - precondition or setup
        BDDMockito.given(bookmarkRepo.findByUserId(Mockito.any(Integer.class))).willReturn(List.of(bookmarkGrievance));

        //when - action or behaviour which needed to be tested
        List<BookmarkGrievance> bookmarkList = bookmarkService.retrieveBookmarksByUserId(1);

        //then - verify output
        Assertions.assertThat(bookmarkList).isNotNull();
        Assertions.assertThat(bookmarkList.size()).isEqualTo(1);
    }

    @Test
    @DisplayName("Junit test for Delete BookmarkGrievance by ComplaintId")
    public void givenComplaintId_whenDeleteBookmarkGrievance_thenDoNothing(){
        //Given - precondition or setup
        String complaintId = "1";
        BDDMockito.given(bookmarkRepo.existsByComplaintId(complaintId)).willReturn(Boolean.TRUE);
        BDDMockito.willDoNothing().given(bookmarkRepo).deleteByComplaintId(complaintId);

        //when - action or behaviour which needed to be tested
        bookmarkService.deleteGrievanceByComplaintId(complaintId);

        //then - verify output
        BDDMockito.verify(bookmarkRepo, Mockito.times(1)).deleteByComplaintId(complaintId);
    }
}
