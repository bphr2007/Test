package com.analysis_service.repository;

import com.analysis_service.model.MedalSummary;
import org.springframework.data.jpa.repository.JpaRepository;



import java.util.List;
import java.util.Optional;

public interface MedalSummaryRepository  extends JpaRepository<MedalSummary, String> {
 /* List<MedalSummary> findByNocIgnoreCase(String NOC);
*/
    /*Optional<MedalSummary> findUserById(Long id);*/
}
