/*
package com.userprofile_service.config;
import com.userprofile_service.model.User;
import com.userprofile_service.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

public class AuthFilter extends GenericFilter{
    @Autowired
    UserService service;

    public AuthFilter(UserService service) {
        this.service = service;
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException, UserNotFoundException {
        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        final String authHeader = request.getHeader("authorization");

        if ("OPTIONS".equals(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            filterChain.doFilter(request, response);
        } else {
            if (authHeader == null || !authHeader.startsWith("Bearer")){
                throw new ServletException("JWT token not present or is invalid");
            }
            String token = authHeader.substring(7);
            Claims claims;
            try{
                claims = Jwts.parser().setSigningKey("secret").parseClaimsJws(token).getBody();
            }catch (ExpiredJwtException e){
                throw new UserNotFoundException("Token Expired");
            }
            System.out.println(claims.getExpiration());
            try{
                User user = service.findByEmail(claims.get("email").toString());

                request.setAttribute("claims" , claims);
                request.setAttribute("user", user.getEmail());
                filterChain.doFilter(request,response);

            }catch (UserNotFoundException e){
                throw new RuntimeException(e.getMessage());
            }

        }
    }

}
*/
