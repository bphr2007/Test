package com.authentication_service.controller;


import com.authentication_service.dto.AuthResponse;
import com.authentication_service.exceptiom.InvalidCredentialsException;
import com.authentication_service.exceptiom.ServiceUnavailableException;

import com.authentication_service.model.UsersDetails;
import com.authentication_service.repository.UserRepository;
import com.authentication_service.security.JwtUtil;
import com.authentication_service.service.AuthService;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private  JwtUtil jwtUtil;
    /*@Autowired
    private  UserProfileClient userProfileClient;*/

    @Autowired
    private AuthService authService;
    @Autowired
    private UserRepository userRepository;
    String token;
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody UsersDetails request) {
        try {
         boolean status=  authService.validateUser(request);

            if(!status) {
                throw new InvalidCredentialsException("Invalid username or password", request.getUsername());

            }
            token = jwtUtil.generateToken(request.getUsername());
            AuthResponse authResponse = new AuthResponse(
                    HttpStatus.OK.value(),
                    "Login successful",
                    token,
                    request.getUsername()
            );
            return ResponseEntity.ok(authResponse);

        } catch (FeignException feignEx) {
            // Check for specific HTTP status from the Feign response
            if (feignEx.status() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidCredentialsException("Invalid username or password", request.getUsername());
            }
            // Generic fallback
            throw new ServiceUnavailableException("User profile service is unavailable");
        }
    }
    @PostMapping("/create")
    public UsersDetails createUser(@RequestBody UsersDetails user) {
        System.out.println("call create method on Auth"+user.getUsername()+" and "+user.getPassword());
        return userRepository.save(user);
    }
}
