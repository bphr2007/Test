package com.authentication_service.repository;

import com.authentication_service.model.UsersDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<UsersDetails,Long> {
    //@Query("SELECT u FROM UsersDetails u WHERE u.userName = :username AND u.password = :password")
    Optional<UsersDetails> findByUsername(String username);


}
