package com.stackroute.userservice.exceptions;

public class UseridNotFoundException extends Exception {
	
	public UseridNotFoundException(String s)
	{
		super(s);
	}

}
