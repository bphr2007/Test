package com.stackroute.grievanceservice.service;

import com.stackroute.grievanceservice.model.GrievanceData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Optional;

@Service
public class GrievanceServiceImpl implements GrievanceService{

    @Autowired
    RestTemplate restTemplate;

    @Value("${external.api.url}")
    private String externalApiUrl;


    @Override
    public List<GrievanceData> findAllGrievances() {
        String url = externalApiUrl + "/grievance";

        ResponseEntity<List<GrievanceData>> responseEntity = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<GrievanceData>>() {}
        );
        return responseEntity.getBody();
    }

    @Override
    public List<GrievanceData> findGrievancesByPropery(String company, String product, String complaintId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString("http://localhost:3232/grievance");
        if(company != null && !company.isBlank()){
            builder.queryParam("company", company);
        } else if(product != null && !product.isBlank()){
            builder.queryParam("product", product);
        } else if(complaintId != null && !complaintId.isBlank()){
            builder.queryParam("complaint_id", complaintId);
        }
        String url = builder.toUriString();
        ResponseEntity<List<GrievanceData>> responseEntity = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<GrievanceData>>() {}
        );
        return responseEntity.getBody();
    }
}
