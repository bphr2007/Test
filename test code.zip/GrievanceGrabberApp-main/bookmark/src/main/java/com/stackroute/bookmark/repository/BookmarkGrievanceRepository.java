package com.stackroute.bookmark.repository;

import com.stackroute.bookmark.model.BookmarkGrievance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookmarkGrievanceRepository extends JpaRepository<BookmarkGrievance, Integer> {
    List<BookmarkGrievance> findByUserId(Integer userId);

    boolean existsByComplaintId(String complaintId);

    void deleteByComplaintId(String complaintId);
}
