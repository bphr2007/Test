package com.analytics_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="MedalDataSummary")
public class MedalDataSummary {
    @Id
    private String id;

    private String NOC;

    private int Gold;

    private int Silver;

    private int Bronze;
    private int Total;
    private int medalRank;

    public MedalDataSummary() {
    }

    public MedalDataSummary(String id, String NOC, int gold, int silver, int bronze, int total, int medalRank) {
        this.id = id;
        this.NOC = NOC;
        Gold = gold;
        Silver = silver;
        Bronze = bronze;
        Total = total;
        this.medalRank = medalRank;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNOC() {
        return NOC;
    }

    public void setNOC(String NOC) {
        this.NOC = NOC;
    }

    public int getGold() {
        return Gold;
    }

    public void setGold(int gold) {
        Gold = gold;
    }

    public int getSilver() {
        return Silver;
    }

    public void setSilver(int silver) {
        Silver = silver;
    }

    public int getBronze() {
        return Bronze;
    }

    public void setBronze(int bronze) {
        Bronze = bronze;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }

    public int getMedalRank() {
        return medalRank;
    }

    public void setMedalRank(int medalRank) {
        this.medalRank = medalRank;
    }

    @Override
    public String toString() {
        return "MedalDataSummary{" +
                "id='" + id + '\'' +
                ", NOC='" + NOC + '\'' +
                ", Gold=" + Gold +
                ", Silver=" + Silver +
                ", Bronze=" + Bronze +
                ", Total=" + Total +
               ", medalRank=" + medalRank +
                '}';
    }
}
