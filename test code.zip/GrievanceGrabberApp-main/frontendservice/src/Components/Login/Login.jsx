import React, { useEffect } from 'react'
import {useFormik} from 'formik'
import * as yup from 'yup'
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { login}  from "../../Store/user";


export default function Login() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const formik=useFormik({
        initialValues:{
            email:"",
            password:"",
        },
        onSubmit:values =>{
            axios.post(`http://localhost:9096/authenticate/login`, values)
           .then(response =>{
            // Store token and userId in sessionStorage
            sessionStorage.setItem('authToken', response.data.tokenInfo.token);
            sessionStorage.setItem('userId', response.data.userId);
            dispatch(login({
                isAuthenticated:true
            }))
        
            navigate("/bookmark");
           })
           .catch(error => {
             console.error('Login failed:', error);
           });
           
        },
        validationSchema:yup.object().shape({
            email:yup.string()
            .email("Invalid email address")
            .required("Email cannot be left blank"),
            password:yup.string()
            .required("Password cannot be left blank"),
            
        })
    })
  return (
    <div className="container">
        <div className="row">
            <div className="col-md-4 offset-md-4">
                <div className="bg-dark text-light py-3 mt-3 text-center rounded">
                    <h2>Login</h2>
                </div>
                <form onSubmit={formik.handleSubmit}>
                    
                    <div className="mt-2">
                    <input id="email" name='email' type="email" onChange={formik.handleChange} onBlur={formik.handleBlur}className="form-control  form-control-sm" value={formik.values.email} placeholder="Email"/>
                    {formik.errors.email && formik.touched.email? <span className='text-danger'>{formik.errors.email}</span>:null}
                    </div>
                  
                   
                   
                    <div className="mt-2">
                    <input id="password" name='password' type="password" onChange={formik.handleChange}onBlur={formik.handleBlur} className="form-control form-control-sm" value={formik.values.password} placeholder="Password"/>
                    {formik.errors.password && formik.touched.password? <span className='text-danger'>{formik.errors.password}</span>:null}
                    </div>
                   
                    <div className="mt-2 ">
                    <button type="submit" className='btn btn-success'>Login</button>
                   
                    </div>

                   
                </form>
            </div>
        </div>
    </div>
  )
}
