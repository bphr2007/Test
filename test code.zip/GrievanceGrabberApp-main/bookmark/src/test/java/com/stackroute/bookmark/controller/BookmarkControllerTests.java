package com.stackroute.bookmark.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.bookmark.dto.BookmarkGrievanceDTO;
import com.stackroute.bookmark.model.BookmarkGrievance;
import com.stackroute.bookmark.service.BookmarkGrievanceService;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

@WebMvcTest(BookmarkController.class)
public class BookmarkControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private BookmarkGrievanceService bookmarkService;

    @Test
    public void givenBookmarkGrievance_whenCreateBookmarkGrievance_thenReturnBookmarkGrievance() throws Exception {
        //given - precondition or setup
        BookmarkGrievanceDTO grievanceDTO = new BookmarkGrievanceDTO(1, "1", "Kotak", "CreditCard",
                "Card Expired", "New Card Replaced", "yes",1);

        BookmarkGrievance bookmarkGrievance = new BookmarkGrievance();
        bookmarkGrievance.setCompany("Kotak");
        bookmarkGrievance.setProduct("CreditCard");
        bookmarkGrievance.setIssue("Card Expired");
        bookmarkGrievance.setCompanyResponse("New Card Replaced");
        bookmarkGrievance.setComplaintId("1");
        bookmarkGrievance.setTimely("yes");
        bookmarkGrievance.setUserId(1);

        BDDMockito.given(bookmarkService.add(ArgumentMatchers.any(BookmarkGrievanceDTO.class))).willReturn(bookmarkGrievance);

        //when - action or behaviour that we are going to Test
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/bookmark/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(grievanceDTO)));

        //then - verify output
        resultActions.andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

    @Test
    public void giveListOfBookmarkGrievance_whenReturnBookmarkGrievanceByUserId_thenReturnListOfBookmarkGrievance() throws Exception {
        //given - precondition or setup
        Integer userId = 1;
        BookmarkGrievance bookmarkGrievance = new BookmarkGrievance();
        bookmarkGrievance.setCompany("Kotak");
        bookmarkGrievance.setProduct("CreditCard");
        bookmarkGrievance.setIssue("Card Expired");
        bookmarkGrievance.setCompanyResponse("New Card Replaced");
        bookmarkGrievance.setComplaintId("1");
        bookmarkGrievance.setTimely("yes");
        bookmarkGrievance.setUserId(1);

        List<BookmarkGrievance> bookmarkGrievanceList = List.of(bookmarkGrievance);
        BDDMockito.given(bookmarkService.retrieveBookmarksByUserId(ArgumentMatchers.any(Integer.class))).willReturn(bookmarkGrievanceList);

        //when - action or behaviour
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.get("/bookmark/user/{userId}", userId));

        //then - verify output
        resultActions.andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath("$.size()", CoreMatchers.is(bookmarkGrievanceList.size())));
    }

    @Test
    public void given_when_then() throws Exception {
        //given - precondition or setup
        String complaintId = "1";
        BDDMockito.willDoNothing().given(bookmarkService).deleteGrievanceByComplaintId(complaintId);

        //when - action or behaviour that we are going to test
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.delete("/bookmark/{complaintId}", complaintId));

        //then - verify output
        resultActions.andExpect(MockMvcResultMatchers.status().isNoContent())
                .andDo(MockMvcResultHandlers.print());
    }

}
