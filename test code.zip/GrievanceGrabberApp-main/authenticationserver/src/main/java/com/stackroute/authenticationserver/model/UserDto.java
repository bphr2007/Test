package com.stackroute.authenticationserver.model;

public record UserDto(String email, String password) {
}
