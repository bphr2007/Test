package com.example.medal.userprofileservice.controller;
import com.example.medal.userprofileservice.model.User;
import com.example.medal.userprofileservice.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/users") public class UserController {
    @Autowired private UserRepository repo;
    @PostMapping("/register") public User register(@RequestBody User user){ return repo.save(user); }
    @GetMapping("/{username}") public User getByUsername(@PathVariable String username){ return repo.findByUsername(username).orElse(null); }
    @PutMapping("/{id}") public User update(@PathVariable Long id, @RequestBody User u){ User user = repo.findById(id).orElseThrow(); user.setEmail(u.getEmail()); user.setFavouriteCountry(u.getFavouriteCountry()); return repo.save(user); }
    @GetMapping public List<User> all(){ return repo.findAll(); }
}