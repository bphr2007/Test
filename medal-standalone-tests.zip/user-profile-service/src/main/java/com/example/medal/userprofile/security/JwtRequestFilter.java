package com.example.medal.userprofile.security;

import com.example.medal.shared.security.JwtUtil;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class JwtRequestFilter extends OncePerRequestFilter {

    private final Environment env;

    public JwtRequestFilter(Environment env) {
        this.env = env;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        // allow registration and validation publicly
        String path = request.getRequestURI();
        if (path.startsWith("/profile/register") || path.startsWith("/profile/validate")) return true;
        // if 'test' profile active, skip auth for tests
        String[] profiles = env.getActiveProfiles();
        return Arrays.asList(profiles).contains("test");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }
        String token = auth.substring(7);
        try {
            JwtUtil.validateToken(token);
            filterChain.doFilter(request, response);
        } catch (JwtException ex) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }
}
