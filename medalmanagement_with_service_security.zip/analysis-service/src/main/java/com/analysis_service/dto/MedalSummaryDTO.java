package com.analysis_service.dto;

public class MedalSummaryDTO {
    private int id;
    /* @JsonProperty(namespace = "noc")
     private String country;*/
    private String NOC;
    private int Gold;
    private int Silver;
    private int Bronze;
    private int Total;
    private int rank;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNOC() {
        return NOC;
    }

    public void setNOC(String NOC) {
        this.NOC = NOC;
    }

    public int getGold() {
        return Gold;
    }

    public void setGold(int gold) {
        Gold = gold;
    }

    public int getSilver() {
        return Silver;
    }

    public void setSilver(int silver) {
        Silver = silver;
    }

    public int getBronze() {
        return Bronze;
    }

    public void setBronze(int bronze) {
        Bronze = bronze;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return "MedalSummaryDTO{" +
                "id=" + id +
                ", NOC='" + NOC + '\'' +
                ", Gold=" + Gold +
                ", Silver=" + Silver +
                ", Bronze=" + Bronze +
                ", Total=" + Total +
                ", rank=" + rank +
                '}';
    }
}
