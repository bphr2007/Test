/*
package com.analysis_service.kafka;

import com.analysis_service.dto.MedalSummaryDTO;
import com.analysis_service.model.MedalSummary;
import com.analysis_service.repository.MedalSummaryRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.lang.reflect.Type;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OlympicConsumer {
    @Autowired
    Gson gson;
    */
/*@Autowired
    private final MedalSummaryRepository repository;

    public OlympicConsumer(MedalSummaryRepository repository) {
        this.repository = repository;
    }
*//*

    //@KafkaListener(topics = "medal-topic", groupId = "group1")
    @KafkaListener(topics = "MedalSummary-topic", groupId = "group1")
    public void consume(String message ) {
        try {


            Type listType = new TypeToken<List<MedalSummaryDTO>>() {
            }.getType();
            List<MedalSummaryDTO> medalDataList = gson.fromJson(message, listType);

            // Filter only records whose id is not in DB
            System.out.println("Data received Successfully" + medalDataList);
            // repository.saveAll(medalDataList);
            System.out.println("Inserted new records: " + medalDataList.size());
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
*/
