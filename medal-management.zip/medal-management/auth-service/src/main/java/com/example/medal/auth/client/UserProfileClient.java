package com.example.medal.auth.client;

import com.example.medal.shared.dto.LoginRequest;
import com.example.medal.shared.dto.ValidateResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "user-profile", url = "${user.profile.url:http://localhost:9100}")
public interface UserProfileClient {
    @PostMapping("/profile/validate")
    ValidateResponse validateCredentials(LoginRequest request);
}
