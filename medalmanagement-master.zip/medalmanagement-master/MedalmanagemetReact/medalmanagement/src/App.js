// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Olympic from './components/Olympic';
import Analytics from './components/Analytics';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/olympic" element={<Olympic />} />
          <Route path="/analytics/:countryCode" element={<Analytics />} />
       
        </Routes>
      </div>
    </Router>
  );
}

export default App;
