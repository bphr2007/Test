Medal Management - Standalone services with tests

How to run tests for each service:
  cd <service>
  mvn test

Note: tests use the 'test' profile which disables JWT auth filters for endpoints where appropriate.
