package com.olympic_service.service;

import com.google.gson.Gson;
import com.olympic_service.model.MedalData;
import jakarta.ws.rs.HttpMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class OlympicService {

    private static final Logger LOGGER = LoggerFactory.getLogger(OlympicService.class);
    private static final String BASE_URL = "http://localhost:3232/olympics";
    private static final String MEDAL_SUMMARY_TOPIC = "MedalSummary-topic";

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final RestTemplate restTemplate;
    private final Gson gson;

    public OlympicService(KafkaTemplate<String, String> kafkaTemplate,
                          RestTemplate restTemplate,
                          Gson gson) {
        this.kafkaTemplate = kafkaTemplate;
        this.restTemplate = restTemplate;
        this.gson = gson;
    }


    public List<MedalData> filterByCountry(String noc) {
        // Step 1: Get all data from the third-party source
        MedalData[] medalArray = restTemplate.getForObject(BASE_URL, MedalData[].class);
        List<MedalData> medals = medalArray != null ? Arrays.asList(medalArray) : new ArrayList<>();

        // Step 2: Filter only by NOC
        List<MedalData> filteredList = medals.stream()
                .filter(d -> noc == null || d.getNOC().equalsIgnoreCase(noc))
                .collect(Collectors.toList());

        // Step 3: Send the filtered list to Kafka
        String jsonPayload = gson.toJson(filteredList);
        kafkaTemplate.send(MEDAL_SUMMARY_TOPIC, jsonPayload);
        LOGGER.info("Sent {} records to Kafka topic '{}'", filteredList.size(), MEDAL_SUMMARY_TOPIC);

        return filteredList;
    }
    public List<String> getCountriesFromMedals() {
        // Fetch the MedalData array from the external service
        RestTemplate restTemplate = new RestTemplate();
        MedalData[] medalArray = restTemplate.getForObject(BASE_URL, MedalData[].class);

            List<String> countries = (medalArray != null)

            ? Arrays.stream(medalArray)  // Convert array to stream
            .map(MedalData::getNOC)  // Map each MedalData to its country
            .collect(Collectors.toList())  // Collect into a list
            : new ArrayList<>();  // Return an empty list if medalArray is null

        return countries;  // Return the list of countries
}






    // Filter + Ranking inside
    /*public List<MedalData> filterBy(String noc, String medalType, Integer minTotal, String rankCriteria) {
        // Step 1: Get all data and sort for ranking
        MedalData[] medalArray = restTemplate.getForObject(BASE_URL, MedalData[].class);
        List<MedalData> medals = medalArray != null ? Arrays.asList(medalArray) : new ArrayList<>();

        List<MedalData> sortedList =medals.stream()
                .sorted((o1, o2) -> {
                    switch (rankCriteria.toLowerCase()) {
                        case "gold": return Integer.compare(o2.getGold(), o1.getGold());
                        case "silver": return Integer.compare(o2.getSilver(), o1.getSilver());
                        case "bronze": return Integer.compare(o2.getBronze(), o1.getBronze());
                        default: return Integer.compare(o2.getTotal(), o1.getTotal());
                    }
                })
                .collect(Collectors.toList());

        // Step 2: Set rank for everyone
        int[] rankCounter = {1};
        sortedList.forEach(d -> d.setMedalRank(rankCounter[0]++));
        System.out.println(sortedList);

        // Step 3: Apply filters
        List<MedalData> finalList= sortedList.stream()
                .filter(d -> (noc == null || d.getNOC().equalsIgnoreCase(noc)))
                .filter(d -> {
                    if (medalType == null) return true;
                    switch (medalType.toLowerCase()) {
                        case "gold": return d.getGold() > 0;
                        case "silver": return d.getSilver() > 0;
                        case "bronze": return d.getBronze() > 0;
                        default: return true;
                    }
                })
                .filter(d -> (minTotal == null || d.getTotal() >= minTotal))
                .collect(Collectors.toList());
        String jsonPayload = gson.toJson(finalList);
        kafkaTemplate.send(MEDAL_SUMMARY_TOPIC, jsonPayload);
        LOGGER.info("Sent {} records to Kafka topic '{}'", finalList.size(), MEDAL_SUMMARY_TOPIC);

        return finalList;
    }*/
}

