package com.example.medal.olympic;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class OlympicControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testImportEndpointReturnsOkEvenIfUpstreamMissing() throws Exception {
        mockMvc.perform(get("/olympic/import"))
                .andExpect(status().isOk());
    }
}
