import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { logout } from '../../Store/user';


export default function Logout() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    
    useEffect(() => {
        sessionStorage.removeItem("authToken");
        sessionStorage.removeItem("userId");
        dispatch(logout())
        //navigate('/login');

    },[])
  return (
    <div><h2>Logout Successful</h2></div>
  )
}
