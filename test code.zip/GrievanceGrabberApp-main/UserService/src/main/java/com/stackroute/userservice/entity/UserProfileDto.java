package com.stackroute.userservice.entity;

public record UserProfileDto (	String name,
        String address,
        String phone,
        String state,
        String zipCode){

}
