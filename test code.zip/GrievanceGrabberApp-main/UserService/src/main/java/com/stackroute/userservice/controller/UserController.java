package com.stackroute.userservice.controller;

import java.util.List;

import com.stackroute.userservice.entity.UserProfileDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stackroute.userservice.entity.UserProfile;
import com.stackroute.userservice.exceptions.UserAlreadyExistException;
import com.stackroute.userservice.exceptions.UseridNotFoundException;
import com.stackroute.userservice.service.UserService;

@RestController
@RequestMapping("user")
public class UserController {
	
	@Autowired
	UserService userservice;
	
	
	@PostMapping("/register")
	public ResponseEntity<UserProfile> adduser(@RequestBody UserProfile user) throws UserAlreadyExistException
	{
	  UserProfile userobj=userservice.registerUser(user);
	  
	  return new ResponseEntity<UserProfile>(userobj,HttpStatus.CREATED);
	}
	
	@GetMapping("/viewAll")
	public ResponseEntity<?> viewall( )
	{
		List<UserProfile> user=userservice.viewAll();
		return new ResponseEntity(user,HttpStatus.OK);
	}
	
	@GetMapping("/viewbyemail/{email}")
	public ResponseEntity<?> viewByEmail(@PathVariable ("email") String email)
	{
		UserProfile user=userservice.viewUserByEmail(email);
		return new ResponseEntity(user,HttpStatus.OK);
	}

	@GetMapping("/{userId}")
	public ResponseEntity<?> getByUserId(@PathVariable ("userId") Integer userId) throws UseridNotFoundException {
		UserProfile user=userservice.viewUserByUserId(userId);
		return new ResponseEntity(user,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> view(@PathVariable ("id") int id) throws UseridNotFoundException
	{
		boolean result=userservice.deleteUser(id);
		return new ResponseEntity(result,HttpStatus.OK);
	}

	@PutMapping("/{userId}")
	public ResponseEntity<?> updateByUserId(@PathVariable ("userId") Integer userId, @RequestBody UserProfileDto userProfileDto) throws UseridNotFoundException {
		UserProfile user=userservice.updateUserProfile(userId, userProfileDto);
		return new ResponseEntity(user,HttpStatus.OK);
	}
}
