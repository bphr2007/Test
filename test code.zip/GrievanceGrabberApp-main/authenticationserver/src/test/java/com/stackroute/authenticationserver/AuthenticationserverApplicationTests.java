package com.stackroute.authenticationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
