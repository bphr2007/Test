package com.example.medal.authservice.client;
import com.example.medal.authservice.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
@FeignClient(name = "userprofile-service", url = "http://localhost:8101")
public interface UserClient { @GetMapping("/users/{username}") UserDTO getByUsername(@PathVariable("username") String username); }