
import React, { useState , useEffect} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Bookmark() {
  const [bookmarkData, setBookmarkData] = useState([]);
  const [refreshDataAfterDelete, setRefreshDataAfterDelete] = useState(false);
  const navigate = useNavigate();

   useEffect(() => {
    axios
      .get(`http://localhost:9096/bookmark/user/${sessionStorage.getItem("userId")}`,
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("authToken")}`
          }
       })
      .then((response) => setBookmarkData(response.data))
      .catch((error) => console.error('Error fetching data:', error));
  },[refreshDataAfterDelete]);

  const deleteBookmarkData = ((bookmarkId) => {
    const headers = {
      "Content-Type":"application/json",
      "Authorization" : `Bearer ${sessionStorage.getItem("authToken")}`
    }
    axios.delete(`http://localhost:9096/bookmark/${bookmarkId}`, { headers })
    .then(() => {
      setRefreshDataAfterDelete(true);
    })
    .catch(error => {
      console.error('Login failed:', error);
    });
  })

  return (
    <div className="container">
        <h2>Bookmark Data</h2>
      <div>
        {bookmarkData.length > 0 && (
          <table class="table table-striped">
            <thead>
              <tr>
                <th>COMPLAINT ID</th>
                <th>COMPANY</th>
                <th>PRODUCT</th>
                <th>ISSUE</th>
                <th>COMPANY RESPONSE</th>
                <th>TIMELY</th>
              </tr>
            </thead>
            <tbody>
              {bookmarkData.map((ele) => (
                <tr key={ele.complaintId}>
                  <td>{ele.complaintId}</td>
                  <td>{ele.company}</td>
                  <td>{ele.product}</td>
                  <td>{ele.issue}</td>
                  <td>{ele.companyResponse}</td>
                  <td>{ele.timely}</td>
                  <td><button class="btn btn-danger" onClick={() => deleteBookmarkData(ele.complaintId)}>DELETE</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {bookmarkData.length == 0 && <p class="text-danger">Sorry No Results, Please provide proper input</p>}
      </div>
    </div>
  );
}

