Medal Management System - Maven Multi-module Skeleton
----------------------------------------------------

Modules:
- discovery-service (Eureka Server placeholder)
- api-gateway (Spring Cloud Gateway placeholder)
- userprofile-service (User CRUD)
- auth-service (Auth + JWT placeholder)
- olympic-service (Fetch olympics API + Kafka producer placeholder)
- analysis-service (Kafka consumer + CRUD)

How to build:
 mvn -v
 cd /path/to/medal-management
 mvn -DskipTests package

Notes:
- This is a starter scaffold. Add dependencies (Eureka, Spring Cloud Gateway, Kafka, Spring Security, Feign) to module poms as needed.
- Configure application.yml files and docker-compose for full local run.
