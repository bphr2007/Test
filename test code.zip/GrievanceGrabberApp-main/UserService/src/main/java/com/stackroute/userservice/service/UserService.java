package com.stackroute.userservice.service;

import java.util.List;

import com.stackroute.userservice.entity.UserProfile;
import com.stackroute.userservice.entity.UserProfileDto;
import com.stackroute.userservice.exceptions.UserAlreadyExistException;
import com.stackroute.userservice.exceptions.UseridNotFoundException;

public interface UserService {

	
	UserProfile registerUser(UserProfile user) throws UserAlreadyExistException;
	boolean deleteUser(int id) throws UseridNotFoundException;
	UserProfile updateUser(UserProfile user) throws UseridNotFoundException;
	UserProfile viewUserByEmail(String email);

	UserProfile viewUserByUserId(Integer userId) throws UseridNotFoundException;
	List<UserProfile> viewByAddr(String addr);
	List<UserProfile> viewAll();

	UserProfile updateUserProfile(Integer userId, UserProfileDto userProfileDto) throws UseridNotFoundException;
	
}
