package com.stackroute.bookmark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmarkApplicationTests {

	@Test
	void contextLoads() {
	}

}
