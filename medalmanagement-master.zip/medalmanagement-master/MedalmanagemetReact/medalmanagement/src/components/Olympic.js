import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './Olympic.css';

function Olympic() {
  const [countries, setCountries] = useState([]); // List of country codes (NOC)
  const [selectedCountry, setSelectedCountry] = useState(''); // Selected country code
  const [countryData, setCountryData] = useState(null); // Data for the selected country (medals)
  const navigate = useNavigate(); // Initialize useNavigate

  // Fetch the list of country codes (NOC) when the component mounts
  useEffect(() => {
    const fetchCountries = async () => {
      const token = localStorage.getItem('token'); // Get the token from localStorage

      if (!token) {
        console.log('No token found, redirecting to login');
        navigate('/login'); // Redirect to login page
        return;
      }

      try {
        const res = await fetch('http://localhost:8085/olympic/countries', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`, // Include token in headers
            'Content-Type': 'application/json',
          },
        });

        const data = await res.json();
        if (res.ok) {
          setCountries(data); // Set the country codes (NOC)
        } else {
          console.log('Failed to fetch countries');
          // Handle token expiration or invalid token
          navigate('/login'); // Redirect to login if authentication fails
        }
      } catch (error) {
        console.error('Error fetching countries:', error);
        navigate('/login'); // Redirect to login on network error
      }
    };

    fetchCountries();
  }, [navigate]);

  // Handle country selection from the dropdown
  const handleCountryChange = async (e) => {
    const countryCode = e.target.value; // Get the selected country code (NOC)
    setSelectedCountry(countryCode);

    // Redirect to the analytics page with the selected country code
    if (countryCode) {
      navigate(`/analytics/${countryCode}`); // Navigate to the analytics page
    }

    // Optionally, you can fetch data for the selected country here (if you still need it)
    const token = localStorage.getItem('token'); // Get the token for the selected country request

    if (!token) {
      console.log('No token found, redirecting to login');
      navigate('/login'); // Redirect if no token found
      return;
    }

    try {
      const res = await fetch(`http://localhost:8085/olympic/country/${countryCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`, // Include token in headers
          'Content-Type': 'application/json',
        },
      });

      const data = await res.json();
      if (res.ok) {
        setCountryData(data); // Set the country data (medals)
      } else {
        console.log('Failed to fetch country data');
        // Handle token expiration or invalid token
        navigate('/login'); // Redirect to login if authentication fails
      }
    } catch (error) {
      console.error('Error fetching country data:', error);
      navigate('/login'); // Redirect to login on network error
    }
  };

  return (
    <div className='centered-container'>
      <h2>Olympic Medal Data</h2>

      {/* Dropdown to select a country */}
      <select onChange={handleCountryChange} value={selectedCountry}>
        <option value="">Select a Country</option>
        {countries.map((countryCode) => (
          <option key={countryCode} value={countryCode}>
            {countryCode} {/* Display country code (NOC) in dropdown */}
          </option>
        ))}
      </select>

      {/* Display the medal data for the selected country */}
      
    </div>
  );
}

export default Olympic;
