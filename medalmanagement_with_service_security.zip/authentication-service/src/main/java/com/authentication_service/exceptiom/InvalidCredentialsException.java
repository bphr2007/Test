package com.authentication_service.exceptiom;

public class InvalidCredentialsException extends RuntimeException {
    private final String username;

    public InvalidCredentialsException(String message, String username) {
        super(message);
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}