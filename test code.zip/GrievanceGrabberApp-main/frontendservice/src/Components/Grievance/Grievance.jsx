import React, { useState , useEffect} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Grievance() {
  const navigate = useNavigate();
  const [grievanceData, setGrievanceData] = useState([]);
  const [filterData, setFilterData] = useState([]);
  const [filterCriteria, setFilterCriteria] = useState({
    company : '',
    product : '',
    issue : ''
  })

   useEffect(() => {
    axios
      .get(`http://localhost:9096/grievances`,
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("authToken")}`
          }
       })
      .then((response) => {
        setGrievanceData(response.data);
        setFilterData(response.data)
        })
      .catch((error) => console.error('Error fetching data:', error));
  },[]);

  const addToBookmark = ((grievanceData) => {
    let payload = {
      complaintId:grievanceData.complaint_id,
      company:grievanceData.company,
      product:grievanceData.product,
      issue: grievanceData.issue,
      companyResponse:grievanceData.company_response,
      timely: grievanceData.timely,
      userId :sessionStorage.getItem("userId")
    }
    const headers = {
      "Content-Type":"application/json",
      "Authorization" : `Bearer ${sessionStorage.getItem("authToken")}`
    }
    axios.post(`http://localhost:9096/bookmark/add`, payload, { headers })
    .then(() => {
      navigate("/bookmark");
    })
    .catch(error => {
      console.error('Login failed:', error);
    });
  })

  const handleFilterChange = ((key, value) => {
    setFilterCriteria(prev => ({
        ...prev,
        [key] : value
    }));
  })

  useEffect(() => {
    console.log(filterCriteria);
    let result = grievanceData;
    if(filterCriteria.company.length > 0){
      result = result.filter(rec => rec.company?.toLowerCase().startsWith(filterCriteria.company.toLowerCase()));
    }
    if(filterCriteria.product.length > 0){
      result = result.filter(rec => rec.product?.toLowerCase().startsWith(filterCriteria.product.toLowerCase()));
    }
    if(filterCriteria.issue.length > 0){
      result = result.filter(rec => rec.issue?.toLowerCase().startsWith(filterCriteria.issue.toLowerCase()));
    }
    setFilterData(result);
  }, [filterCriteria, grievanceData]);

  const clearFilterCriteria = () => {
    setFilterCriteria({
      company : '',
      product : '',
      issue : ''
    });
  }

  return (
    <div className="container">
      <div class="my-5">
        <div class="row">
            <div class="col-3">
              <input type="text" class="form-control" placeholder="Filter By Company" aria-label="Filter By Company"
               onChange={e => handleFilterChange('company', e.target.value)}/>
            </div>
            <div class="col-3">
              <input type="text" class="form-control" placeholder="Filter By Product" aria-label="Filter By Product" 
              onChange={e => handleFilterChange('product', e.target.value)}/>
            </div>
            <div class="col-3">
              <input type="text" class="form-control" placeholder="Filter By Issue" aria-label="Filter By Issue" 
              onChange={e => handleFilterChange('issue', e.target.value)}/>
            </div>
            <div class="col-1">
              <button type="btn btn-secondary" onClick={clearFilterCriteria}>Clear</button>
            </div>
        </div>
      </div>
        <h2>Grievance Data</h2>
      <div>
        {filterData.length > 0 && (
          <table class="table table-striped">
            <thead>
              <tr>
                <th>COMPLAINT ID</th>
                <th>COMPANY</th>
                <th>PRODUCT</th>
                <th>ISSUE</th>
                <th>COMPANY RESPONSE</th>
                <th>TIMELY</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filterData.map((ele) => (
                <tr key={ele.complaint_id}>
                  <td>{ele.complaint_id}</td>
                  <td>{ele.company}</td>
                  <td>{ele.product}</td>
                  <td>{ele.issue}</td>
                  <td>{ele.company_response}</td>
                  <td>{ele.timely}</td>
                  <td><button class="btn btn-secondary" onClick={() => addToBookmark(ele)}>ADD</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {filterData.length === 0 && <p class="text-danger">Sorry No Results, Please provide proper input</p>}
      </div>
    </div>
  );
}

