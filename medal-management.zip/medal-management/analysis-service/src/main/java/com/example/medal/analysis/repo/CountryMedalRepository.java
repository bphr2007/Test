package com.example.medal.analysis.repo;

import com.example.medal.analysis.model.CountryMedal;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CountryMedalRepository extends JpaRepository<CountryMedal, Long> {
    Optional<CountryMedal> findByNoc(String noc);
}
