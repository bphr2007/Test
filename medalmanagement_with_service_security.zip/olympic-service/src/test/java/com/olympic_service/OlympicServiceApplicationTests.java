package com.olympic_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlympicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
