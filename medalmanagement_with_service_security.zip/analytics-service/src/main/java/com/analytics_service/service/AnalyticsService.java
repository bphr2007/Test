package com.analytics_service.service;

import com.analytics_service.model.MedalDataSummary;
import com.analytics_service.repository.AnalyticsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnalyticsService {
    @Autowired
    AnalyticsRepository analyticsRepository;

    public List<MedalDataSummary> getAll() {
        return analyticsRepository.findAll();
    }

    public MedalDataSummary save(MedalDataSummary data) {
        return analyticsRepository.save(data);
    }

    public void delete(String id) {
        analyticsRepository.deleteById(id);
    }

    public MedalDataSummary update(String id, MedalDataSummary data) {
        MedalDataSummary existing = analyticsRepository.findById(id).orElseThrow();
        existing.setGold(data.getGold());
        existing.setSilver(data.getSilver());
        existing.setBronze(data.getBronze());
        existing.setTotal(data.getTotal());
        existing.setMedalRank(data.getMedalRank());
        return analyticsRepository.save(existing);
    }

    public List<MedalDataSummary> getByGoldRanking() {
        return analyticsRepository.findAll()
                .stream()
                .sorted(Comparator.comparingInt(MedalDataSummary::getGold).reversed())
                .toList();
    }

    public MedalDataSummary filterByCountry(String NOC) {
        return analyticsRepository.findByNOC(NOC);
    }

   /* public List<MedalDataSummary> filterByMedalType(String type) {
        List<MedalDataSummary> types=analyticsRepository.findByTypeIgnoreCase(type);
        return types.stream().filter(data -> {
            switch (type.toLowerCase()) {
                case "gold": return data.getGold() > 0;
                case "silver": return data.getSilver() > 0;
                case "bronze": return data.getBronze() > 0;
                default: return false;
            }
        }).collect(Collectors.toList());
    }*/

    public List<MedalDataSummary> getRankings() {
        return analyticsRepository.findAll().stream()
                .sorted(Comparator.comparingInt(MedalDataSummary::getMedalRank))
                .collect(Collectors.toList());
    }
}
