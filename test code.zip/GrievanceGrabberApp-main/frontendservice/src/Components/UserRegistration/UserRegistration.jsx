import { Formik, useFormik } from 'formik'
import * as yup from 'yup'
import React, { useEffect, useState } from 'react'
import axios from 'axios'; 

export default function UserRegistration() {
  const [updateResponseFlag, setUpdateResponseFlag] = useState('not-started')

  const formik=useFormik({
    initialValues:{
      name: '',
      email: '',
      password: '',
      address: '',
      phone: '',
      state: '',
      zipCode: ''
    },
    enableReinitialize: true, 
    onSubmit:values=>{
      console.log(values);
      let userId = sessionStorage.getItem("userId");
      fetch(`http://localhost:9096/user/register`,{
        method:"POST",
        headers:{
          "Content-Type":"application/json"
        },
        body:JSON.stringify(values)
      })
      .then(res=>res.json())
      .then(data => {
        console.log("UserProfile Updated successfully");
        setUpdateResponseFlag("success");
      })
      .catch(err => {
        setUpdateResponseFlag("failed");
      })

    },
    validationSchema:yup.object().shape({
      name:yup.string()
      .required("Name cannot be left blank"),
      email:yup.string()
      .required("Email cannot be left blank"),
      password:yup.string()
      .required("Password cannot be left blank"),
      address:yup.string()
      .required("Address cannot be left blank"),
      phone:yup.string()
      .required("Phone cannot be left blank"),
      state:yup.string()
      .required("State cannot be left blank"),
      zipCode:yup.string()
      .required("ZipCode cannot be left blank")
    })
  })
  return (
    <div className='container m-3'>
      <div className='row'>
        { updateResponseFlag === "not-started" &&
        <div className='col-md-4 offset-md-4'>
          <div className='bg-dark text-light py-3 text-center rounded'>
            <h2>Update User Profile</h2>
          </div>
          <form onSubmit={formik.handleSubmit}>
            <div className="mt-3">
              <input type="text" class="form-control" id="name" name='name' placeholder="User Name" value={formik.values.name} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
              {formik.errors.name && formik.touched.name ? <span className='text-danger'>{formik.errors.name} </span>:null}
            </div>  
            <div className="mt-3">
              <input type="email" class="form-control" id="email" name='email' placeholder="Email" value={formik.values.email} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
            </div>
            <div className="mt-3">
              <input type="password" class="form-control" id="password" name='password' placeholder="Password" value={formik.values.password} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
            </div>
            <div className="mt-3">
              <input type="text" class="form-control" id="address" name='address' placeholder="Address" value={formik.values.address} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
              {formik.errors.address && formik.touched.address ? <span className='text-danger'>{formik.errors.address} </span>:null}
            </div>
            <div className="mt-3">
              <input type="text" class="form-control" id="phone" name='phone' placeholder="Phone" value={formik.values.phone} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
              {formik.errors.phone && formik.touched.phone ? <span className='text-danger'>{formik.errors.phone} </span>:null}
            </div>
            <div className="mt-3">
              <input type="text" class="form-control" id="state" name='state' placeholder="State" value={formik.values.state} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
              {formik.errors.state && formik.touched.state ? <span className='text-danger'>{formik.errors.state} </span>:null}
            </div>
            <div className="mt-3">
              <input type="text" class="form-control" id="zipCode" name='zipCode' placeholder="ZipCode" value={formik.values.zipCode} onChange={formik.handleChange} onBlur={formik.handleBlur}/>
              {formik.errors.zipCode && formik.touched.zipCode ? <span className='text-danger'>{formik.errors.zipCode} </span>:null}
            </div>
             <div className="mt-3">
              <button type='submit' className='btn btn-success col-12'>Submit</button>
            </div>
          </form>
        </div>
         }
        { updateResponseFlag === "success" && <h3>User Profile Created Successfully</h3>}
        { updateResponseFlag === "failed" && <h3>User Profile Creation Not Success</h3>}
      </div>
    </div>
  )
}
