package com.example.medal.authservice.util;
import io.jsonwebtoken.Jwts; import io.jsonwebtoken.security.Keys; import java.security.Key; import java.util.Date;
public class JwtUtil {
    private static final Key key = Keys.hmacShaKeyFor("ReplaceThisWithASecureKeyOfAtLeast32Bytes!".getBytes());
    public static String generateToken(String username){ return Jwts.builder().setSubject(username).setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis()+1000L*60*60*24)).signWith(key).compact(); }
    public static String getUsername(String token){ return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody().getSubject(); }
}