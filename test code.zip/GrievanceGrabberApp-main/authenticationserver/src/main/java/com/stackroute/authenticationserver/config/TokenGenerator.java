package com.stackroute.authenticationserver.config;

import com.stackroute.authenticationserver.model.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TokenGenerator {

	private static final String SECRET = "u7X9vA3kL2pQ8rT5sY1eW9zB6mN4cJ7dF0gH3aK8lV2xR5tU";
	private static final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());

	public static Map<String, String> getToken(User customer) {
		long expiry = 100_000_000;

		Map<String, Object> claims = new HashMap<>();
		claims.put("useremail", customer.getUseremail());
		claims.put("role", "admin");

		String token = Jwts.builder()
				.setClaims(claims)
				.setSubject("grievanceapp")
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + expiry))
				.signWith(key, SignatureAlgorithm.HS256) // ✅ new API
				.compact();

		Map<String, String> tokenData = new HashMap<>();
		tokenData.put("token", token);
		return tokenData;
	}
}
