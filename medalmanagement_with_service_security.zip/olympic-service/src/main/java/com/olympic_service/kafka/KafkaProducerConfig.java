package com.olympic_service.kafka;

import com.olympic_service.model.MedalSummary;
import org.apache.kafka.common.serialization.StringSerializer;
import com.olympic_service.model.MedalData;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class KafkaProducerConfig {
   /* @Bean
    public ProducerFactory<String, MedalData> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        config.put("spring.json.trusted.packages", "com.olympic_service.model"); // Use your real package here

        return new DefaultKafkaProducerFactory<>(config);
    }
*/
  /* @Bean
   public ProducerFactory<String, List<MedalSummary>>producerFactory() {
       Map<String, Object> config = new HashMap<>();
       config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
       config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
       config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
       return new DefaultKafkaProducerFactory<>(config);
   }

    @Bean
    public KafkaTemplate<String, List<MedalSummary>> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }*/
}