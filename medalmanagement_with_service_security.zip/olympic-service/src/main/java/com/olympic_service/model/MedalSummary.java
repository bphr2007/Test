package com.olympic_service.model;



public class MedalSummary {

    private String id;
   /* @JsonProperty(namespace = "noc")
    private String country;*/
    private String noc;
    private int gold;
    private int silver;
    private int bronze;
    private int total;

    public MedalSummary() {
    }

    public MedalSummary(String id, String country, String noc, int gold, int silver, int bronze, int total) {
        this.id = id;

        this.noc = noc;
        this.gold = gold;
        this.silver = silver;
        this.bronze = bronze;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

   

    public String getNoc() {
        return noc;
    }

    public void setNoc(String noc) {
        this.noc = noc;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getSilver() {
        return silver;
    }

    public void setSilver(int silver) {
        this.silver = silver;
    }

    public int getBronze() {
        return bronze;
    }

    public void setBronze(int bronze) {
        this.bronze = bronze;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "MedalSummary{" +
                "id='" + id + '\'' +

                ", noc='" + noc + '\'' +
                ", gold=" + gold +
                ", silver=" + silver +
                ", bronze=" + bronze +
                ", total=" + total +
                '}';
    }
}
