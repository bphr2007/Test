package com.authentication_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@EnableDiscoveryClient
@SpringBootApplication
public class AuthenticationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationServiceApplication.class, args);
	}
	/*@Configuration
	public static class WebConfig implements WebMvcConfigurer {
		*//*@Override
		public void addCorsMappings(CorsRegistry registry) {
			registry.addMapping("/**") // Remove this mapping to disable CORS
					.allowedOrigins("http://localhost:3000") // Remove any origins to disable
					.allowedMethods("GET", "POST", "PUT", "DELETE") // Remove methods to disable
					.allowedHeaders("*") // Remove to disable headers
					.allowCredentials(true); // Remove to disable credentials
		}*/

}
