package com.stackroute.authenticationserver.controller;

import java.util.Map;
import java.util.Optional;

import com.stackroute.authenticationserver.model.AuthenticatedUser;
import com.stackroute.authenticationserver.model.User;
import com.stackroute.authenticationserver.model.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.authenticationserver.config.TokenGenerator;
import com.stackroute.authenticationserver.service.AuthenticationService;

 

@RestController
@RequestMapping("/authenticate")
public class AuthenticationController {
	
	@Autowired
	AuthenticationService cservice;

	@PostMapping("/login")
	public ResponseEntity<AuthenticatedUser> login(@RequestBody UserDto user)
	{
		Optional<User> userOptional = cservice.validateUser(user);
		
		if(userOptional.isPresent())
		{
			Map tokendata=TokenGenerator.getToken(userOptional.get());
			AuthenticatedUser authUser = new AuthenticatedUser(userOptional.get().getId(), tokendata);
			return ResponseEntity.ok(authUser);
		}
		else
		{
			return new ResponseEntity("Invalid credentials",HttpStatus.FORBIDDEN);
		}
	}
}
