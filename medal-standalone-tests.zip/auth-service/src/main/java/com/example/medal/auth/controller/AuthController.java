package com.example.medal.auth.controller;

import com.example.medal.shared.dto.LoginRequest;
import com.example.medal.shared.dto.ValidateResponse;
import com.example.medal.shared.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final RestTemplate rt = new RestTemplate();
    private final String userProfileUrl;

    public AuthController() {
        this.userProfileUrl = System.getenv().getOrDefault("USER_PROFILE_URL", "http://localhost:9100/profile/validate");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        try {
            ResponseEntity<ValidateResponse> resp = rt.postForEntity(userProfileUrl, req, ValidateResponse.class);
            if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null || !resp.getBody().isValid()) {
                return ResponseEntity.status(401).body(Map.of("error","invalid credentials"));
            }
            var token = JwtUtil.generateToken(req.getUsername(), Map.of("roles", resp.getBody().getRoles()));
            return ResponseEntity.ok(Map.of("token", token));
        } catch (Exception ex) {
            return ResponseEntity.status(500).body(Map.of("error","cannot validate user", "detail", ex.getMessage()));
        }
    }
}
