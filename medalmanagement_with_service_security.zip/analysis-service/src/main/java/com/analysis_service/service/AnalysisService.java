package com.analysis_service.service;

import com.analysis_service.model.MedalSummary;
import com.analysis_service.repository.MedalSummaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnalysisService {
    @Autowired
    private  MedalSummaryRepository repository;

    public List<MedalSummary> getAll() {
        return repository.findAll();
    }

    public MedalSummary save(MedalSummary data) {
        return repository.save(data);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public MedalSummary update(String id, MedalSummary data) {
        MedalSummary existing = repository.findById(id).orElseThrow();
        existing.setGold(data.getGold());
        existing.setSilver(data.getSilver());
        existing.setBronze(data.getBronze());
        existing.setTotal(data.getTotal());
        return repository.save(existing);
    }

    public List<MedalSummary> getByGoldRanking() {
        return repository.findAll()
                .stream()
                .sorted(Comparator.comparingInt(MedalSummary::getGold).reversed())
                .toList();
    }

 /* public List<MedalSummary> filterByCountry(String country) {
        return repository.findByNocIgnoreCase(country);
    }

    public List<MedalSummary> filterByMedalType(String type) {
        return repository.findAll().stream().filter(data -> {
            switch (type.toLowerCase()) {
                case "gold": return data.getGold() > 0;
                case "silver": return data.getSilver() > 0;
                case "bronze": return data.getBronze() > 0;
                default: return false;
            }
        }).collect(Collectors.toList());
    }*/

    public List<MedalSummary> getRankings() {
        return repository.findAll().stream()
                .sorted(Comparator.comparingInt(MedalSummary::getTotal).reversed())
                .collect(Collectors.toList());
    }
}
