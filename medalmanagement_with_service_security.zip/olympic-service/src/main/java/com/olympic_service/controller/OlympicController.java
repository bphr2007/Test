package com.olympic_service.controller;

import com.olympic_service.model.MedalData;
import com.olympic_service.service.OlympicService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/olympic")

public class OlympicController {
    @Autowired
    private  OlympicService olympicService;

    @GetMapping("country/{noc}")
    public List<MedalData> getMedalsByNOC(@PathVariable String noc) {
        return olympicService.filterByCountry(noc);
    }

    @GetMapping("/countries")
    public List<String> getCountries() {
        return olympicService.getCountriesFromMedals();  // Get countries from the service
    }
   /* @GetMapping("/filter")
    public List<MedalData> getByNoc(
            @RequestParam(required = false) String noc,
            @RequestParam(required = false) String medalType,
            @RequestParam(required = false) Integer minTotal,
            @RequestParam(defaultValue = "total") String rankCriteria
    ) {
        return olympicService.filterBy(noc, medalType, minTotal, rankCriteria);
    }*/


}
