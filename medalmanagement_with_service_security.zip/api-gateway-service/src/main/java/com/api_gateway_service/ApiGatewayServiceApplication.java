package com.api_gateway_service;

import com.api_gateway_service.filter.JWTValidationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

import org.springframework.web.bind.annotation.CrossOrigin;


import java.util.Arrays;


@EnableDiscoveryClient
@SpringBootApplication

public class ApiGatewayServiceApplication {

	@Autowired
	JWTValidationFilter jwtValidationFilter;
	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayServiceApplication.class, args);
	}

	/*@Bean
	public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
		return http
				.csrf(ServerHttpSecurity.CsrfSpec::disable)
				.authorizeExchange(exchange -> exchange
						.anyExchange().permitAll()
				)
				.build();
	}
	@Bean
	public CorsWebFilter corsWebFilter() {
		CorsConfiguration corsConfig = new CorsConfiguration();
		corsConfig.setAllowedOrigins(Arrays.asList("http://localhost:3000")); // Your React app URL
		corsConfig.setMaxAge(3600L);
		corsConfig.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		corsConfig.setAllowedHeaders(Arrays.asList("*"));
		corsConfig.setAllowCredentials(true);
		corsConfig.addExposedHeader("Authorization");

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", corsConfig);
		return new CorsWebFilter(source);
	}*/
	@Bean
	public RouteLocator apiRoutes(RouteLocatorBuilder builder) {
		return builder.routes()
				.route("authentication-service", route -> route.path("/auth/**").uri("lb://authentication-service"))
				.route("userprofile-route", route -> route.path("/users/**").uri("lb://userprofile-service"))
				.route("olympic-route", route -> route.path("/olympic/**").filters(temp -> temp.filter(jwtValidationFilter)).uri("lb://olympic-service"))
				.route("analytics-service", route -> route.path("/analytics/**").filters(temp -> temp.filter(jwtValidationFilter)).uri("lb://analytics-service"))
				.build();
		/*uri("lb://userprofile-service"))*/
				/*.route("olympic-route", route -> route.path("/olympic/**").uri("lb://olympic-service"))
				.route("analysis-route", route -> route.path("/analysis/**")
						/*.filters(temp -> temp.filter(jwtValidationFilter)).uri("lb://analysis-service"))

				.build();*/
	}
}
