package com.analysis_service.model;

import jakarta.persistence.*;

@Entity
@Table(name = "MedalSummary")
public class MedalSummary {
    @Id
    private String id;
    private String NOC;
    private int Gold;
    private int Silver;
    private int Bronze;
    private int Total;

    private int rank;


    public MedalSummary() {
    }

    public MedalSummary(String id, String noc, int gold, int silver, int bronze, int total,int rank) {
        this.id = id;

        this.NOC = noc;
        this.Gold = gold;
        this.Silver = silver;
        this.Bronze = bronze;
        this.Total = total;
        this.rank=rank;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    public String getNoc() {
        return NOC;
    }

    public void setNoc(String noc) {
        this.NOC = noc;
    }

    public int getGold() {
        return Gold;
    }

    public void setGold(int gold) {
        this.Gold = gold;
    }

    public int getSilver() {
        return Silver;
    }

    public void setSilver(int silver) {
        this.Silver = silver;
    }

    public int getBronze() {
        return Bronze;
    }

    public void setBronze(int bronze) {
        this.Bronze = bronze;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        this.Total = total;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return "MedalSummary{" +
                "id='" + id + '\'' +

                ", noc='" + NOC + '\'' +
                ", gold=" + Gold +
                ", silver=" + Silver +
                ", bronze=" + Bronze +
                ", total=" + Total +
                ", rank=" + rank +
                '}';
    }
}
