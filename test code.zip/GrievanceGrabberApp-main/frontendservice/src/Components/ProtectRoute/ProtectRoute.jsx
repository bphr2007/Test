import React from 'react';
import { useSelector } from 'react-redux';
import Login from '../Login/Login';

export default function ProtectRoute({ children }) {
  const token = sessionStorage.getItem("authToken");

  if (!token) {
    return <Login />;
  }

  return children;
}
