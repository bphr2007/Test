package com.api_gateway;

import com.api_gateway.filter.JWTValidationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {
	@Autowired
	private JWTValidationFilter jwtValidationFilter;




	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}


	@Bean
	public RouteLocator apiRoutes(RouteLocatorBuilder builder) {
		return builder.routes()
				.route("userprofile-route", route -> route.path("/users/**").uri("lb://userprofile-service"))

				.build();
						/*uri("lb://userprofile-service"))*/
				/*.route("olympic-route", route -> route.path("/olympic/**").uri("lb://olympic-service"))
				.route("analysis-route", route -> route.path("/analysis/**")*/
						/*.filters(temp -> temp.filter(jwtValidationFilter)).uri("lb://analysis-service"))

				.build();*/
	}
}
