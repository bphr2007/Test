package com.stackroute.bookmark.dto;

public record BookmarkGrievanceDTO(Integer bookmarkId, String complaintId, String company, String product, String issue, String companyResponse,
                                   String timely, Integer userId) {
}
