package com.stackroute.userservice.exceptions;

public class UserAlreadyExistException extends Exception {
	
	public UserAlreadyExistException(String s)
	{
		super(s);
		
	}

}
