package com.example.medal.userprofile.controller;

import com.example.medal.shared.dto.LoginRequest;
import com.example.medal.shared.dto.ValidateResponse;
import com.example.medal.userprofile.model.UserProfile;
import com.example.medal.userprofile.repo.UserProfileRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/profile")
public class UserProfileController {

    private final UserProfileRepository repo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public UserProfileController(UserProfileRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody UserProfile up) {
        up.setPassword(encoder.encode(up.getPassword()));
        var saved = repo.save(up);
        saved.setPassword(null);
        return ResponseEntity.status(201).body(saved);
    }

    @PostMapping("/validate")
    public ValidateResponse validateCredentials(@RequestBody LoginRequest req) {
        Optional<UserProfile> uo = repo.findByUsername(req.getUsername());
        if (uo.isEmpty()) return new ValidateResponse(false, null);
        UserProfile u = uo.get();
        boolean ok = encoder.matches(req.getPassword(), u.getPassword());
        return new ValidateResponse(ok, ok ? u.getRoles() : null);
    }

    @GetMapping("/me/{username}")
    public ResponseEntity<?> me(@PathVariable String username) {
        var u = repo.findByUsername(username);
        if (u.isEmpty()) return ResponseEntity.notFound().build();
        var up = u.get();
        up.setPassword(null);
        return ResponseEntity.ok(up);
    }
}
