package com.stackroute.userservice.service;

import java.util.List;
import java.util.Optional;

import com.google.gson.Gson;
import com.stackroute.userservice.entity.UserDto;
import com.stackroute.userservice.entity.UserProfileDto;
import jakarta.transaction.Transactional;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.stackroute.userservice.entity.UserProfile;
import com.stackroute.userservice.exceptions.UserAlreadyExistException;
import com.stackroute.userservice.exceptions.UseridNotFoundException;
import com.stackroute.userservice.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepo;

	@Autowired
	KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	Gson gson;

	@Override
	@Transactional
	public UserProfile registerUser(UserProfile user) throws UserAlreadyExistException {
		
		Optional<UserProfile> optUser = userRepo.findByEmail(user.getEmail());
		
		if (optUser.isPresent()) {
			throw new UserAlreadyExistException("UserId Already Available");
		} else {
			UserProfile userProfile = userRepo.save(user);
			UserDto userDto = new UserDto(userProfile.getEmail(), userProfile.getPassword());
			kafkaTemplate.send("registerusertopic", gson.toJson(userDto));
			return userProfile;
		}
	}

	@Override
	public boolean deleteUser(int userid)  throws UseridNotFoundException{
		Optional<UserProfile> optuser=userRepo.findById(userid);

		if (optuser.isEmpty()) {
			throw new UseridNotFoundException("User Does nto exist for update");
		}

		userRepo.deleteById(userid);
 		return true;
	}

	@Override
	public UserProfile updateUser(UserProfile user) throws UseridNotFoundException {

		Optional<UserProfile> optuser=userRepo.findById(user.getUserId());

		if (optuser.isEmpty())
		{
			throw new UseridNotFoundException("User Does nto exist for update");
		}
		return userRepo.save(user);

	}

	@Override
	public UserProfile viewUserByEmail(String email) {
 		return userRepo.findByEmail(email).get();
	}

	@Override
	public UserProfile viewUserByUserId(Integer userId) throws UseridNotFoundException {
		Optional<UserProfile> userProfileOptional = userRepo.findById(userId);
		if (userProfileOptional.isEmpty())
		{
			throw new UseridNotFoundException("User Does nto exist for update");
		}
		return userProfileOptional.get();
	}

	@Override
	public List<UserProfile> viewByAddr(String addr) {
 		return userRepo.findByAddress(addr);
	}

	@Override
	public List<UserProfile> viewAll() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public UserProfile updateUserProfile(Integer userId, UserProfileDto userProfileDto) throws UseridNotFoundException {
		Optional<UserProfile> userProfileOptional = userRepo.findById(userId);
		if (userProfileOptional.isEmpty())
		{
			throw new UseridNotFoundException("User Does nto exist for update");
		}
		UserProfile userProfile = userProfileOptional.get();
		userProfile.setName(userProfileDto.name());
		userProfile.setPhone(userProfileDto.phone());
		userProfile.setAddress(userProfileDto.address());
		userProfile.setState(userProfileDto.state());
		userProfile.setZipCode(userProfileDto.zipCode());
		return userRepo.save(userProfile);
	}

}
