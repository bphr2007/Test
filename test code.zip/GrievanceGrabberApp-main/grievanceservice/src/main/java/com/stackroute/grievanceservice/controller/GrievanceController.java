package com.stackroute.grievanceservice.controller;

import com.stackroute.grievanceservice.model.GrievanceData;
import com.stackroute.grievanceservice.service.GrievanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("grievances")
public class GrievanceController {

    @Autowired
    GrievanceService grievanceService;

    @GetMapping()
    public ResponseEntity<List<GrievanceData>> retieveAllGrievanceData(){
        List<GrievanceData> grievanceDataList = grievanceService.findAllGrievances();
        return ResponseEntity.ok(grievanceDataList);
    }

    @GetMapping("/search")
    public ResponseEntity<List<GrievanceData>> getGrievancesByProperty(
            @RequestParam(required=false) String company,
            @RequestParam(required = false) String product,
            @RequestParam(required = false) String complaintId){
        List<GrievanceData> grievanceDataList = grievanceService.findGrievancesByPropery(company, product, complaintId);
        return ResponseEntity.ok(grievanceDataList);
    }


}
