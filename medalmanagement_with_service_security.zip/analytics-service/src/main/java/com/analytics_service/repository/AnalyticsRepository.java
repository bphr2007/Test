package com.analytics_service.repository;

import com.analytics_service.model.MedalDataSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface AnalyticsRepository extends JpaRepository<MedalDataSummary,String> {

    MedalDataSummary findByNOC(String NOC);


}
