package com.analysis_service.controller;

import com.analysis_service.model.MedalSummary;
import com.analysis_service.service.AnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/analysis")
public class AnalysisController {
    @Autowired
    AnalysisService analysisService;

    @GetMapping("/getMedalData")
    public ResponseEntity<List<MedalSummary>> getMedalData() {
        return ResponseEntity.ok(analysisService.getAll());
    }

    /*@GetMapping("/filterByCountry/{country}")
    public ResponseEntity<List<MedalSummary>> filterByCountry(@PathVariable String noc) {
        return ResponseEntity.ok(analysisService.filterByCountry(noc));
    }

    @GetMapping("/filterByMedalType/{type}")
    public ResponseEntity<List<MedalSummary>> filterByType(@PathVariable String type) {
        return ResponseEntity.ok(analysisService.filterByMedalType(type));
    }*/

    @GetMapping("/getRankings")
    public ResponseEntity<List<MedalSummary>> getRankings() {
        return ResponseEntity.ok(analysisService.getRankings());
    }
   @PostMapping
    public ResponseEntity<MedalSummary> create(@RequestBody MedalSummary data) {
     return ResponseEntity.ok(analysisService.save(data));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MedalSummary> update(@PathVariable String id, @RequestBody MedalSummary data) {
        return ResponseEntity.ok(analysisService.update(id, data));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        analysisService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/rankings/gold")
    public ResponseEntity<List<MedalSummary>> rankByGold() {
        return ResponseEntity.ok(analysisService.getByGoldRanking());
    }
}
