package com.example.medal.auth.controller;

import com.example.medal.auth.client.UserProfileClient;
import com.example.medal.shared.dto.LoginRequest;
import com.example.medal.shared.dto.ValidateResponse;
import com.example.medal.shared.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserProfileClient userProfileClient;

    public AuthController(UserProfileClient userProfileClient) {
        this.userProfileClient = userProfileClient;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        ValidateResponse vr = userProfileClient.validateCredentials(req);
        if (vr == null || !vr.isValid()) {
            return ResponseEntity.status(401).body(Map.of("error","invalid credentials"));
        }
        var token = JwtUtil.generateToken(req.getUsername(), Map.of("roles", vr.getRoles()));
        return ResponseEntity.ok(Map.of("token", token));
    }
}
