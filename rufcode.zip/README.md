Medal Management System - Complete Maven Multi-module Project
------------------------------------------------------------

Modules:
- discovery-service (Eureka Server)
- api-gateway (Spring Cloud Gateway)
- userprofile-service (User CRUD, MySQL)
- auth-service (Feign client to userprofile + simple JWT generator)
- olympic-service (Fetch olympic API and publish to Kafka)
- analysis-service (Kafka consumer -> saves MedalSummary to MySQL)

Defaults (change these in each service application.yml before running):
- MySQL: jdbc:mysql://localhost:3306/medal_db  (user: root, pass: root)
- Kafka: localhost:9092
- Olympic API: run the container described in the case study and make it available at http://localhost:3232/olympicapi/olympics

Build:
  mvn -DskipTests package

Run order (recommended):
  1. Start MySQL and ensure database access (the app will create DB/tables if permitted)
  2. Start Kafka broker at localhost:9092
  3. Start discovery-service
  4. Start userprofile-service
  5. Start auth-service
  6. Start olympic-service
  7. Start analysis-service
  8. Start api-gateway (optional, you can call services directly)

Example calls:
- Register user:
  POST http://localhost:8101/users/register  { "username":"alice","password":"pass","email":"a@b.com" }

- Login and get JWT:
  POST http://localhost:8102/auth/login { "username":"alice","password":"pass" }

- Fetch Olympics and publish to Kafka:
  GET http://localhost:8103/olympics/fetch

- See rankings:
  GET http://localhost:8104/analysis/rankings?by=gold

Notes:
- This is a working starter project. You may want to harden JWT secret, add password hashing, add security filters, and improve error handling.
- Ports, DB creds, and Kafka settings are intentionally simple for local development; change before production.
