package com.example.medal.shared.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Date;
import java.util.Map;

public class JwtUtil {
    // FOR DEMO ONLY: replace with env secret in production
    public static final String SECRET = "change_this_long_secret_to_env_var_in_production_change_this_long_secret";
    private static final Key KEY = Keys.hmacShaKeyFor(SECRET.getBytes());
    public static final long EXPIRATION_MS = 1000L * 60 * 60 * 24; // 24h

    public static String generateToken(String username, Map<String, Object> claims) {
        return Jwts.builder()
            .setClaims(claims)
            .setSubject(username)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_MS))
            .signWith(KEY)
            .compact();
    }

    public static Jws<Claims> validateToken(String token) throws JwtException {
        return Jwts.parserBuilder().setSigningKey(KEY).build().parseClaimsJws(token);
    }

    public static String getUsername(String token) {
        return validateToken(token).getBody().getSubject();
    }
}
