import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css'; // Uncomment if you have custom CSS for styling

function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false); // State to manage loading state

  // Navigate to the registration page
  const registerFirst = () => {
    navigate("/register");
  };

  // Handle login submission
  const handleLogin = async () => {
    if (!username || !password) {
      setMsg("Username and password are required.");
      return;
    }

    setLoading(true); // Set loading state to true while the request is being processed

    try {
      const res = await fetch('http://localhost:8085/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      // Check if response is ok, otherwise show error message
      if (!res.ok) {
        const data = await res.json();
        setMsg(data.message || 'Login failed');
        return;
      }

      const data = await res.json();
      console.log(data.token);
      localStorage.setItem('token', data.token);
      localStorage.setItem('username', data.username);
      
      setMsg('Login successful!');
      navigate('/olympic');  // Navigate to the Olympic page on successful login
    } catch (error) {
   
      setMsg('Something went wrong. Please try again.');
    } finally {
      setLoading(false);  // Reset loading state once the request is complete
    }
  };

  return (
    <div className="login-container">
      <button onClick={registerFirst}>No Account? Register First</button>
      <h3>Login with your credentials</h3>

      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        disabled={loading} // Disable inputs when loading
      />
      <br />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        disabled={loading} // Disable inputs when loading
      />
      <br />

      <button onClick={handleLogin} disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>

      {/* Display message or error */}
      {msg && <p>{msg}</p>}
    </div>
  );
}

export default Login;
