import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Register.css';
function Register() {
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [age, setAge] = useState('');
  const [msg, setMsg] = useState('');

  const handleRegister = async () => {
    try {
      const res = await fetch('http://localhost:8085/users/addUser', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName,
          lastName,
          username,
          password,
          phone,
          country,
          age
        })
      });

      const data = await res.json();

      if (!res.ok) {
        setMsg(data.message || 'Registration failed');
        return;
      }

      setMsg('Registration successful! Please login.');
      navigate('/');  // Navigate to the Login page
    } catch (error) {
      console.error('Registration error:', error);
      setMsg('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="register-container">
      <h3>Register a new account</h3>
      
      <input
        type="text"
        placeholder="First Name"
        value={firstName}
        onChange={e => setFirstName(e.target.value)}
      /><br/>
      
      <input
        type="text"
        placeholder="Last Name"
        value={lastName}
        onChange={e => setLastName(e.target.value)}
      /><br/>
      
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={e => setUsername(e.target.value)}
      /><br/>
      
     
      
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      /><br/>
      
      <input
        type="text"
        placeholder="Phone"
        value={phone}
        onChange={e => setPhone(e.target.value)}
      /><br/>
      
      <input
        type="text"
        placeholder="Country"
        value={country}
        onChange={e => setCountry(e.target.value)}
      /><br/>
      
      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={e => setAge(e.target.value)}
      /><br/>
      
      <button onClick={handleRegister}>Register</button>
      <p>{msg}</p>
    </div>
  );
}

export default Register;
