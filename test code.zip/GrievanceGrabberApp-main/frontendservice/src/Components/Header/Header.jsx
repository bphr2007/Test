import React, {useState} from 'react'
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function Header() {
  const authInfo=useSelector(state=> state.user.value);
  //const [isAuthenticated, setIsAuthenticated] = useState(sessionStorage.getItem("authToken") ? true: false);
  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Fourth navbar example">
    <div className="container-fluid">     
      <div className="collapse navbar-collapse" id="navbarsExample04">
        <ul className="navbar-nav me-auto mb-2 mb-md-0">
          <li className="nav-item">
            <Link className="nav-link active" aria-current="page"  to="/bookmark">Bookmark</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/grievance">Grievance</Link>
          </li>
        </ul>
        {authInfo.isAuthenticated === true && 
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
            <Link className="nav-link" to="/updateUserProfile">Update User Profile</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/logout">Logout</Link>
            </li>
          </ul>
        }
        {authInfo.isAuthenticated === false && 
          <ul className="navbar-nav ms-auto">
             <li className="nav-item">
              <Link className="nav-link" to="/register">RegisterNewUser</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/login">Login</Link>
            </li>
          </ul>
        }
        
      </div>
    </div>
  </nav>

  )
}
