package com.example.medal.shared.dto;

public class ValidateResponse {
    private boolean valid;
    private String roles;

    public ValidateResponse() {}
    public ValidateResponse(boolean valid, String roles) { this.valid = valid; this.roles = roles; }
    public boolean isValid() { return valid; }
    public void setValid(boolean valid) { this.valid = valid; }
    public String getRoles() { return roles; }
    public void setRoles(String roles) { this.roles = roles; }
}
