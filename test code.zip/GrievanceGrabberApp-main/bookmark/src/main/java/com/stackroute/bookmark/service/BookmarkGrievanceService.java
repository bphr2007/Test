package com.stackroute.bookmark.service;

import com.stackroute.bookmark.dto.BookmarkGrievanceDTO;
import com.stackroute.bookmark.model.BookmarkGrievance;

import java.util.List;

public interface BookmarkGrievanceService {

    public BookmarkGrievance add(BookmarkGrievanceDTO grievance);

    public List<BookmarkGrievance> retrieveBookmarksByUserId(Integer userId);

    public void deleteGrievanceByComplaintId(String complaintId);
}
