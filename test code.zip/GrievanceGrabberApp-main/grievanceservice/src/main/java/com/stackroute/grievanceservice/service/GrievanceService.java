package com.stackroute.grievanceservice.service;

import com.stackroute.grievanceservice.model.GrievanceData;

import java.util.List;

public interface GrievanceService {
    public List<GrievanceData> findAllGrievances();

    List<GrievanceData> findGrievancesByPropery(String company, String product, String complaintId);
}
