package com.stackroute.gatewayserver.helper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

import io.jsonwebtoken.security.Keys;
import java.security.Key;


public class JwtUtil {


    private static final String SECRET = "u7X9vA3kL2pQ8rT5sY1eW9zB6mN4cJ7dF0gH3aK8lV2xR5tU";
    private static final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());


    public Claims validateToken(String token) throws Exception {
        return Jwts.parser()
                   .setSigningKey(key)
                   .parseClaimsJws(token)
                   .getBody();
    }
}
