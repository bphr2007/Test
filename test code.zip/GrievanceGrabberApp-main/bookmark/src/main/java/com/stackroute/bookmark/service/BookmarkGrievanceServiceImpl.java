package com.stackroute.bookmark.service;

import com.stackroute.bookmark.dto.BookmarkGrievanceDTO;
import com.stackroute.bookmark.exception.ResourceNotFoundException;
import com.stackroute.bookmark.model.BookmarkGrievance;
import com.stackroute.bookmark.repository.BookmarkGrievanceRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookmarkGrievanceServiceImpl implements BookmarkGrievanceService{

    @Autowired
    BookmarkGrievanceRepository bookmarkRepository;

    @Override
    public BookmarkGrievance add(BookmarkGrievanceDTO grievanceDTO) {
        if(bookmarkRepository.existsByComplaintId(grievanceDTO.complaintId())){
            throw new ResourceNotFoundException("BookmarkGrievance already exists  with ComplaintID: "+grievanceDTO.complaintId());
        }
        BookmarkGrievance grievance = new BookmarkGrievance();
        grievance.setComplaintId(grievanceDTO.complaintId());
        grievance.setCompany(grievanceDTO.company());
        grievance.setProduct(grievanceDTO.product());
        grievance.setIssue(grievanceDTO.issue());
        grievance.setCompanyResponse(grievanceDTO.companyResponse());
        grievance.setTimely(grievanceDTO.timely());
        grievance.setUserId(grievanceDTO.userId());
        return bookmarkRepository.save(grievance);
    }

    @Override
    public List<BookmarkGrievance> retrieveBookmarksByUserId(Integer userId) {
        return bookmarkRepository.findByUserId(userId);
    }

    @Override
    @Transactional
    public void deleteGrievanceByComplaintId(String complaintId) {
        if(!bookmarkRepository.existsByComplaintId(complaintId)){
            System.out.println("BookmarkGrievance not found");
            throw new ResourceNotFoundException("BookmarkGrievance Not Found with ComplaintID: "+complaintId);
        }
         bookmarkRepository.deleteByComplaintId(complaintId);
    }
}
