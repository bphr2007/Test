package com.example.medal.authservice.controller;
import com.example.medal.authservice.client.UserClient;
import com.example.medal.authservice.dto.UserDTO;
import com.example.medal.authservice.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/auth") public class AuthController {
    @Autowired private UserClient userClient;
    @PostMapping("/login") public String login(@RequestBody LoginRequest req){
        UserDTO u = userClient.getByUsername(req.getUsername());
        if(u!=null && u.getPassword().equals(req.getPassword())){ return JwtUtil.generateToken(u.getUsername()); }
        throw new RuntimeException("Invalid credentials"); }
    public static class LoginRequest { private String username; private String password; public String getUsername(){return username;} public void setUsername(String username){this.username=username;} public String getPassword(){return password;} public void setPassword(String password){this.password=password;} }
}