package com.authentication_service.service;

import com.authentication_service.model.UsersDetails;
import com.authentication_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class AuthService {

    @Autowired
    UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public boolean validateUser(UsersDetails request) {

        UsersDetails user = userRepository.findByUsername(request.getUsername()).orElse(null);
             return user != null && user.getPassword().equals(request.getPassword());
        }
    public List<UsersDetails> getAllUsers(){

        return userRepository.findAll();
    }


}
