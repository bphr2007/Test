package com.stackroute.userservice.entity;

public record UserDto(String email, String password) {
}
