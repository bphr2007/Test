package com.userprofile_service.service;

import com.userprofile_service.dto.AuthRequest;
import com.userprofile_service.dto.UserDTO;
import com.userprofile_service.exception.InvalidCredentialsException;
import com.userprofile_service.feign.AuthServiceClient;
import com.userprofile_service.model.User;
import com.userprofile_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    AuthServiceClient authServiceClient;
    @Autowired
    private  UserRepository userRepository;


    AuthRequest authUserRequest=new AuthRequest();
    public User create(User user) {
        boolean exists = userRepository.findByUsername(user.getUsername()).isPresent();
        if (exists) {
            throw new RuntimeException("Username already exists");
        }
        User finalUser = userRepository.save(user);
        try {
        authUserRequest.setUserid(finalUser.getUserid());
        authUserRequest.setUsername(finalUser.getUsername());
        authUserRequest.setPassword(finalUser.getPassword());
        authServiceClient.createAuthUser(authUserRequest);
        } catch (Exception e) {
            e.printStackTrace();
            userRepository.delete(finalUser);
            throw new RuntimeException("Failed to create auth user: " + e.getMessage(), e);
        }
        return finalUser;
    }
    public User update(Long id, User updatedUser) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + id));

        user.setUsername(updatedUser.getUsername());
        user.setPassword(updatedUser.getPassword());
        user.setPhone(updatedUser.getPhone());
        user.setCountry(updatedUser.getCountry());
        user.setAge(updatedUser.getAge());
        user.setFirstName(updatedUser.getFirstName());
        user.setLastName(updatedUser.getLastName());

        /*User updatedUserForFiegn = userRepository.save(user);

            authUserRequest.setUserName(user.getUsername());
            authUserRequest.setPassword(user.getPassword());
            authServiceClient.createAuthUser(authUserRequest);*/

        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public void delete(Long id) {
        userRepository.deleteById(id);
    }

    public User getById(Long id) {
        return userRepository.findById(id).orElseThrow();
    }

    
}
