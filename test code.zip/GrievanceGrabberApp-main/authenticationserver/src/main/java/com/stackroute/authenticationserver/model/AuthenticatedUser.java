package com.stackroute.authenticationserver.model;

import java.util.Map;

public class AuthenticatedUser {

    Integer userId;
    Map<String, String> tokenInfo;

    public AuthenticatedUser(Integer userId, Map<String, String> tokenInfo) {
        this.userId = userId;
        this.tokenInfo = tokenInfo;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Map<String, String> getTokenInfo() {
        return tokenInfo;
    }

    public void setTokenInfo(Map<String, String> tokenInfo) {
        this.tokenInfo = tokenInfo;
    }
}
